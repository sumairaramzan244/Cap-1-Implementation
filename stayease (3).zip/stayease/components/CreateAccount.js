

// import React, { useState } from 'react';
// import { Text, View, TextInput, ImageBackground, StyleSheet, TouchableOpacity, Alert } from 'react-native';

// const CreateAccount = ({ navigation }) => {
//   const [name, setName] = useState('');
//   const [username, setUsername] = useState('');
//   const [contactNumber, setContactNumber] = useState('');
//   const [cnic, setCnic] = useState('');
//   const [address, setAddress] = useState('');
//   const [password, setPassword] = useState('');
//   const [confirmPassword, setConfirmPassword] = useState('');
//   const [errors, setErrors] = useState({});
//   const [showPassword, setShowPassword] = useState(false);
//   const [showConfirmPassword, setShowConfirmPassword] = useState(false);

//   const validateForm = () => {
//     let newErrors = {};
//     let hasError = false;

//     // Name Validation
//     if (!name.trim()) {
//       newErrors.name = 'Full Name is required';
//       hasError = true;
//     }

//     // Email Validation
//     if (!username.trim()) {
//       newErrors.email = 'Email is required';
//       hasError = true;
//     } else if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(username)) {
//       newErrors.email = 'Invalid email format';
//       hasError = true;
//     }

//     // Contact Number Validation
//     if (!contactNumber.trim()) {
//       newErrors.contactNumber = 'Contact Number is required';
//       hasError = true;
//     } else if (contactNumber.length !== 11) {
//       newErrors.contactNumber = 'Contact Number must be 11 digits';
//       hasError = true;
//     }

//     // CNIC Validation
//     if (!cnic.trim()) {
//       newErrors.cnic = 'CNIC is required';
//       hasError = true;
//     } else if (cnic.length !== 13) {
//       newErrors.cnic = 'CNIC must be 13 characters long';
//       hasError = true;
//     }

//     // Address Validation
//     if (!address.trim()) {
//       newErrors.address = 'Address is required';
//       hasError = true;
//     }

//     // Password Validation
//     let passwordErrors = [];
//     if (!password.trim()) {
//       passwordErrors.push("Password is required.");
//     } else {
//       if (password.length < 6) {
//         passwordErrors.push("Password must be at least 6 characters long.");
//       }
//       if (!/[a-z]/.test(password)) {
//         passwordErrors.push("Password must contain at least one lowercase letter.");
//       }
//       if (!/[A-Z]/.test(password)) {
//         passwordErrors.push("Password must contain at least one uppercase letter.");
//       }
//       if (!/[0-9]/.test(password)) {
//         passwordErrors.push("Password must contain at least one number.");
//       }
//       if (!/[\W_]/.test(password)) {
//         passwordErrors.push("Password must contain at least one special character (e.g., !, @, #, $, etc.).");
//       }
//     }

//     if (passwordErrors.length > 0) {
//       newErrors.password = passwordErrors.join("\n");
//       hasError = true;
//     }

//     // Confirm Password Validation
//     if (!confirmPassword.trim()) {
//       newErrors.confirmPassword = 'Confirm Password is required';
//       hasError = true;
//     } else if (confirmPassword !== password) {
//       newErrors.confirmPassword = 'Passwords do not match';
//       hasError = true;
//     }

//     setErrors(newErrors);
//     return !hasError;
//   };

//   // Function to handle form submission
//   const buttonHandler = () => {
//     if (!validateForm()) {
//       Alert.alert('Error', 'Please fix the errors before proceeding.');
//       return;
//     }

//     Alert.alert('Success', 'Account Created Successfully');
//     navigation.navigate('Login');
    
//   };

//   return (
//     <ImageBackground 
//       source={{ uri: 'https://source.unsplash.com/1600x900/?nature,abstract' }} 
//       style={styles.background}
//       resizeMode="cover"
//     >
//       <View style={styles.container}>
//         <Text style={styles.title}>Create Account</Text>
//         <View style={styles.inputContainer}>

//           {/* Full Name */}
//           <Text style={styles.label}>Full Name</Text>
//           <TextInput
//             placeholder="Enter Full Name"
//             style={[styles.input, errors.name && styles.errorInput]}
//             value={name}
//             onChangeText={setName}
//           />
//           {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

//           {/* Email */}
//           <Text style={styles.label}>Email</Text>
//           <TextInput
//             placeholder="Enter Email"
//             style={[styles.input, errors.email && styles.errorInput]}
//             value={username}
//             onChangeText={setUsername}
//           />
//           {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

//           {/* Contact Number */}
//           <Text style={styles.label}>Contact Number</Text>
//           <TextInput
//             placeholder="Enter Contact Number"
//             style={[styles.input, errors.contactNumber && styles.errorInput]}
//             keyboardType="numeric"
//             value={contactNumber}
//             onChangeText={setContactNumber}
//           />
//           {errors.contactNumber && <Text style={styles.errorText}>{errors.contactNumber}</Text>}

//           {/* CNIC */}
//           <Text style={styles.label}>CNIC</Text>
//           <TextInput
//             placeholder="Enter CNIC"
//             style={[styles.input, errors.cnic && styles.errorInput]}
//             keyboardType="numeric"
//             value={cnic}
//             onChangeText={setCnic}
//           />
//           {errors.cnic && <Text style={styles.errorText}>{errors.cnic}</Text>}

//           {/* Address */}
//           <Text style={styles.label}>Address</Text>
//           <TextInput
//             placeholder="Enter Address"
//             style={[styles.input, errors.address && styles.errorInput]}
//             value={address}
//             onChangeText={setAddress}
//           />
//           {errors.address && <Text style={styles.errorText}>{errors.address}</Text>}

//           {/* Password */}
//           <Text style={styles.label}>Password</Text>
//           <View style={styles.passwordContainer}>
//             <TextInput
//               placeholder="Enter Password"
//               style={[styles.input, { flex: 1 }]}
//               secureTextEntry={!showPassword}
//               value={password}
//               onChangeText={setPassword}
//             />
//             <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
//               <Text style={styles.eyeText}>{showPassword ? "🙈" : "👁️"}</Text>
//             </TouchableOpacity>
//           </View>
//           {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

//           {/* Confirm Password */}
//           <Text style={styles.label}>Confirm Password</Text>
//           <View style={styles.passwordContainer}>
//             <TextInput
//               placeholder="Confirm Password"
//               style={[styles.input, { flex: 1 }]}
//               secureTextEntry={!showConfirmPassword}
//               value={confirmPassword}
//               onChangeText={setConfirmPassword}
//             />
//             <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.eyeIcon}>
//               <Text style={styles.eyeText}>{showConfirmPassword ? "🙈" : "👁️"}</Text>
//             </TouchableOpacity>
//           </View>
//           {errors.confirmPassword && <Text style={styles.errorText}>{errors.confirmPassword}</Text>}

//           {/* Signup Button */}
//           <TouchableOpacity style={styles.button} onPress={buttonHandler}>
//             <Text style={styles.buttonText}>Signup</Text>
//           </TouchableOpacity>

//         </View>
//       </View>
//     </ImageBackground>
//   );
// };
// const styles = StyleSheet.create({
//   background: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     width: '100%',
//     height: '100%',
//   },
//   container: {
//     backgroundColor: 'rgba(255, 255, 255, 0.9)',
//     padding: 25,
//     borderRadius: 15,
//     width: '85%',
//     alignItems: 'center',
//     borderColor: '#ddd',
//     borderWidth: 1,
//     shadowColor: '#000',
//     shadowOffset: { width: 2, height: 4 },
//     shadowOpacity: 0.2,
//     shadowRadius: 6,
//     elevation: 5, // For Android shadow
//   },
//   title: {
//     fontSize: 28,
//     marginBottom: 20,
//     fontWeight: 'bold',
//     color: '#333',
//     textAlign: 'center',
//   },
//   inputContainer: {
//     width: '100%',
//   },
//   label: {
//     fontSize: 16,
//     fontWeight: '500',
//     marginBottom: 5,
//     color: '#555',
//   },
//   input: {
//     height: 45,
//     borderColor: '#bbb',
//     borderWidth: 1,
//     marginBottom: 12,
//     paddingHorizontal: 15,
//     borderRadius: 10,
//     backgroundColor: '#f9f9f9',
//   },
//   errorInput: {
//     borderColor: 'red',
//   },
//   errorText: {
//     color: 'red',
//     fontSize: 12,
//     marginBottom: 10,
//     fontWeight: '500',
//   },
//   passwordContainer: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     borderColor: '#bbb',
//     borderWidth: 1,
//     borderRadius: 10,
//     marginBottom: 12,
//     paddingHorizontal: 15,
//     backgroundColor: '#f9f9f9',
//   },
//   eyeIcon: {
//     padding: 10,
//   },
//   eyeText: {
//     fontSize: 18,
//     color: '#555',
//   },
//   button: {
//     backgroundColor: '#5A67D8',
//     padding: 12,
//     borderRadius: 10,
//     alignItems: 'center',
//     width: '100%',
//     marginTop: 10,
//     shadowColor: '#000',
//     shadowOffset: { width: 2, height: 4 },
//     shadowOpacity: 0.2,
//     shadowRadius: 6,
//     elevation: 3, // For Android
//   },
//   buttonText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 16,
//   },
// });

// export default CreateAccount;




import React, { useState } from 'react';
import { Text, View, TextInput, ImageBackground, StyleSheet, TouchableOpacity, Alert } from 'react-native';

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

const CreateAccount = ({ navigation }) => {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [cnic, setCnic] = useState('');
  const [address, setAddress] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const validateForm = () => {
    let newErrors = {};
    let hasError = false;

    if (!name.trim()) {
      newErrors.name = 'Full Name is required';
      hasError = true;
    }

    if (!username.trim()) {
      newErrors.username = 'Email is required';
      hasError = true;
    } else if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(username)) {
      newErrors.username = 'Invalid email format';
      hasError = true;
    }

    if (!contactNumber.trim()) {
      newErrors.contactNumber = 'Contact Number is required';
      hasError = true;
    } else if (contactNumber.length !== 11) {
      newErrors.contactNumber = 'Contact Number must be 11 digits';
      hasError = true;
    }

    if (!cnic.trim()) {
      newErrors.cnic = 'CNIC is required';
      hasError = true;
    } else if (cnic.length !== 13) {
      newErrors.cnic = 'CNIC must be 13 characters long';
      hasError = true;
    }

    if (!address.trim()) {
      newErrors.address = 'Address is required';
      hasError = true;
    }

    let passwordErrors = [];
    if (!password.trim()) {
      passwordErrors.push("Password is required.");
    } else {
      if (password.length < 6) {
        passwordErrors.push("Password must be at least 6 characters long.");
      }
      if (!/[a-z]/.test(password)) {
        passwordErrors.push("Password must contain at least one lowercase letter.");
      }
      if (!/[A-Z]/.test(password)) {
        passwordErrors.push("Password must contain at least one uppercase letter.");
      }
      if (!/[0-9]/.test(password)) {
        passwordErrors.push("Password must contain at least one number.");
      }
      if (!/[\W_]/.test(password)) {
        passwordErrors.push("Password must contain at least one special character.");
      }
    }

    if (passwordErrors.length > 0) {
      newErrors.password = passwordErrors.join("\n");
      hasError = true;
    }

    if (!confirmPassword.trim()) {
      newErrors.confirmPassword = 'Confirm Password is required';
      hasError = true;
    } else if (confirmPassword !== password) {
      newErrors.confirmPassword = 'Passwords do not match';
      hasError = true;
    }

    setErrors(newErrors);
    return !hasError;
  };
const buttonHandler = async () => {
  if (!validateForm()) {
    Alert.alert('Error', 'Please fix the errors before proceeding.');
    return;
  }

  try {
    console.log('Sending sign-up request...');
    const response = await fetch(
      'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU',
      {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: username, // Ensure email is sent to Firebase Auth
          password: password,
          returnSecureToken: true,
        }),
      }
    );

    const result = await response.json();
    console.log('Sign-up response:', result);

    if (result.idToken) {
      const userId = result.localId;
      console.log('Saving user data to Firebase...');

      const saveResponse = await fetch(
        `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${result.idToken}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: name,
            email: username, // ✅ Ensure email is stored in the database
            contactNumber: contactNumber,
            cnic: cnic,
            address: address,
            password: password, // You may want to hash this for security
          }),
        }
      );

      const saveResult = await saveResponse.json();
      console.log('User data saved:', saveResult);

      Alert.alert('Success', 'Signup Successful');
      navigation.navigate('Login');
    } else {
      console.log('Error in sign-up result:', result);
      Alert.alert('Error', result.error?.message || 'Credentials do not match');
    }
  } catch (error) {
    console.error('Error occurred:', error);
    Alert.alert('Error', 'An error occurred. Please try again.');
  }
};
    return (
    <ImageBackground 
      source={{ uri: 'https://source.unsplash.com/1600x900/?nature,abstract' }} 
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.container}>
        <Text style={styles.title}>Create Account</Text>
        <View style={styles.inputContainer}>

          {/* Full Name */}
          <Text style={styles.label}>Full Name</Text>
          <TextInput
            placeholder="Enter Full Name"
            style={[styles.input, errors.name && styles.errorInput]}
            value={name}
            onChangeText={setName}
          />
          {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

          {/* Email */}
          <Text style={styles.label}>Email</Text>
          <TextInput
            placeholder="Enter Email"
            style={[styles.input, errors.email && styles.errorInput]}
            value={username}
            onChangeText={setUsername}
          />
          {errors.email && <Text style={styles.errorText}>{errors.email}</Text>}

          {/* Contact Number */}
          <Text style={styles.label}>Contact Number</Text>
          <TextInput
            placeholder="Enter Contact Number"
            style={[styles.input, errors.contactNumber && styles.errorInput]}
            keyboardType="numeric"
            value={contactNumber}
            onChangeText={setContactNumber}
          />
          {errors.contactNumber && <Text style={styles.errorText}>{errors.contactNumber}</Text>}

          {/* CNIC */}
          <Text style={styles.label}>CNIC</Text>
          <TextInput
            placeholder="Enter CNIC"
            style={[styles.input, errors.cnic && styles.errorInput]}
            keyboardType="numeric"
            value={cnic}
            onChangeText={setCnic}
          />
          {errors.cnic && <Text style={styles.errorText}>{errors.cnic}</Text>}

          {/* Address */}
          <Text style={styles.label}>Address</Text>
          <TextInput
            placeholder="Enter Address"
            style={[styles.input, errors.address && styles.errorInput]}
            value={address}
            onChangeText={setAddress}
          />
          {errors.address && <Text style={styles.errorText}>{errors.address}</Text>}

          {/* Password */}
          <Text style={styles.label}>Password</Text>
          <View style={styles.passwordContainer}>
            <TextInput
              placeholder="Enter Password"
              style={[styles.input, { flex: 1 }]}
              secureTextEntry={!showPassword}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
              <Text style={styles.eyeText}>{showPassword ? "🙈" : "👁️"}</Text>
            </TouchableOpacity>
          </View>
          {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

          {/* Confirm Password */}
          <Text style={styles.label}>Confirm Password</Text>
          <View style={styles.passwordContainer}>
            <TextInput
              placeholder="Confirm Password"
              style={[styles.input, { flex: 1 }]}
              secureTextEntry={!showConfirmPassword}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
            />
            <TouchableOpacity onPress={() => setShowConfirmPassword(!showConfirmPassword)} style={styles.eyeIcon}>
              <Text style={styles.eyeText}>{showConfirmPassword ? "🙈" : "👁️"}</Text>
            </TouchableOpacity>
          </View>
          {errors.confirmPassword && <Text style={styles.errorText}>{errors.confirmPassword}</Text>}

          {/* Signup Button */}
          <TouchableOpacity style={styles.button} onPress={buttonHandler}>
            <Text style={styles.buttonText}>Signup</Text>
          </TouchableOpacity>

        </View>
      </View>
    </ImageBackground>
  );
};
const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
  },
  container: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 25,
    borderRadius: 15,
    width: '85%',
    alignItems: 'center',
    borderColor: '#ddd',
    borderWidth: 1,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5, // For Android shadow
  },
  title: {
    fontSize: 28,
    marginBottom: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  inputContainer: {
    width: '100%',
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 5,
    color: '#555',
  },
  input: {
    height: 45,
    borderColor: '#bbb',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 15,
    borderRadius: 10,
    backgroundColor: '#f9f9f9',
  },
  errorInput: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    fontSize: 12,
    marginBottom: 10,
    fontWeight: '500',
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: '#bbb',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 12,
    paddingHorizontal: 15,
    backgroundColor: '#f9f9f9',
  },
  eyeIcon: {
    padding: 10,
  },
  eyeText: {
    fontSize: 18,
    color: '#555',
  },
  button: {
    backgroundColor: '#5A67D8',
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    width: '100%',
    marginTop: 10,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3, // For Android
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default CreateAccount;
