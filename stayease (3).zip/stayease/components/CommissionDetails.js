import React from 'react';
import { View, Text, StyleSheet, TextInput, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const CommissionDetails = ({ navigation }) => {
    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <Ionicons
                    name="arrow-back-outline"
                    size={24}
                    color="#000"
                    onPress={() => navigation.goBack()} // Navigate back to AdminDashboard
                />
                <Text style={styles.headerTitle}>Commission Payments</Text>
                <Ionicons name="notifications-outline" size={24} color="#000" />
            </View>

            {/* Search Bar */}
            <View style={styles.searchBarContainer}>
                <Ionicons name="search-outline" size={20} color="gray" style={styles.searchIcon} />
                <TextInput
                    placeholder="commission"
                    style={styles.searchInput}
                    placeholderTextColor="gray"
                />
            </View>

            {/* User Info */}
            <View style={styles.userInfoContainer}>
                <Image
                    source={{ uri: 'https://randomuser.me/api/portraits/women/1.jpg' }}
                    style={styles.profileImage}
                />
                <View>
                    <Text style={styles.userName}>unknown </Text>
                    <Text style={styles.userEmail}>unknown @email.com</Text>
                    <Text style={styles.userContact}>+923074698327</Text>
                    <Text style={styles.userRole}>Landlord</Text>
                </View>
            </View>

            {/* Property Details */}
            <View style={styles.propertyCard}>
                <Image
                    source={{
                        uri: 'https://via.placeholder.com/100x100.png?text=Property+Image',
                    }}
                    style={styles.propertyImage}
                />
                <View>
                    <Text style={styles.propertyTitle}>Bridgeland Luxury Apartment</Text>
                    <Text style={styles.propertyDetails}>12 months rent</Text>
                    <Text style={styles.propertyPrice}>Rs. 90,000/month</Text>
                </View>
            </View>

            {/* Property Information */}
            <View style={styles.propertyInfoContainer}>
                <Text style={styles.sectionTitle}>Property Information</Text>
                <Text style={styles.propertyInfo}>Location: Lahore</Text>
                <Text style={styles.propertyInfo}>Apartment: 2 Beds, 2 Baths</Text>
                <Text style={styles.propertyInfo}>Registered: 01-Aug-2023</Text>
            </View>

            {/* Commission Information */}
            <View style={styles.commissionContainer}>
                <Text style={styles.sectionTitle}>Total Commission</Text>
                <Text style={styles.commissionAmount}>Rs. 10,000</Text>
            </View>

            {/* Mark as Paid Button */}
            <TouchableOpacity style={styles.markAsPaidButton}>
                <Text style={styles.buttonText}>Mark as Paid</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FA',
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#000',
    },
    searchBarContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        borderRadius: 8,
        paddingHorizontal: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
        marginBottom: 20,
    },
    searchIcon: {
        marginRight: 10,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#333333',
    },
    userInfoContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 20,
    },
    profileImage: {
        width: 60,
        height: 60,
        borderRadius: 30,
        marginRight: 15,
    },
    userName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#000',
    },
    userEmail: {
        fontSize: 14,
        color: '#666',
    },
    userContact: {
        fontSize: 14,
        color: '#666',
    },
    userRole: {
        fontSize: 14,
        color: '#4A90E2',
    },
    propertyCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        padding: 15,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 3,
        marginBottom: 20,
    },
    propertyImage: {
        width: 100,
        height: 100,
        borderRadius: 10,
        marginRight: 15,
    },
    propertyTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#000',
    },
    propertyDetails: {
        fontSize: 14,
        color: '#666',
    },
    propertyPrice: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#4A90E2',
    },
    propertyInfoContainer: {
        marginBottom: 20,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#000',
        marginBottom: 5,
    },
    propertyInfo: {
        fontSize: 14,
        color: '#666',
        marginBottom: 5,
    },
    commissionContainer: {
        marginBottom: 20,
    },
    commissionAmount: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#4A90E2',
    },
    markAsPaidButton: {
        backgroundColor: '#5CB85C',
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    buttonText: {
        fontSize: 16,
        color: '#ffffff',
        fontWeight: 'bold',
    },
});

export default CommissionDetails;
