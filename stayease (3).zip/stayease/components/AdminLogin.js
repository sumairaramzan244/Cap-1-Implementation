




// import React, { useState } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   Alert,
//   StyleSheet,
//   ImageBackground,
// } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const AdminLogin = ({ navigation }) => {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [errors, setErrors] = useState({});

//   const validateForm = () => {
//     let newErrors = {};
//     let hasError = false;

//     if (!username) {
//       newErrors.username = "Email is required.";
//       hasError = true;
//     } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
//       newErrors.username = "Invalid email format.";
//       hasError = true;
//     }

//     if (!password) {
//       newErrors.password = "Password is required.";
//       hasError = true;
//     }

//     setErrors(newErrors);
//     return !hasError;
//   };

//   const handleLogin = async () => {
//     if (!validateForm()) return;

//     try {
//       const response = await fetch(
//         "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU", // Replace with your Firebase API Key
//         {
//           method: "POST",
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             email: username,
//             password: password,
//             returnSecureToken: true,
//           }),
//         }
//       );

//       const result = await response.json();
//       console.log("API Response:", result);

//       if (response.ok && result.idToken) {
//         // Save the token and user info to AsyncStorage
//         await AsyncStorage.setItem("idToken", result.idToken);
//         await AsyncStorage.setItem("userId", result.localId);

//         // Check if the logged-in user is the admin
//         if (username === "211400125@gift.edu.pk") {
//           Alert.alert("Success", "Logged in successfully as admin!");
//           navigation.navigate("AdminDashboard", { idToken: result.idToken });
//         } else {
//           Alert.alert("Access Denied", "You are not authorized to access the admin dashboard.");
//           // Optionally, redirect to a user dashboard or home page
//           navigation.navigate("UserDashboard"); // Replace this with actual navigation for non-admin users
//         }
//       } else {
//         Alert.alert("Error", result.error?.message || "Invalid credentials.");
//       }
//     } catch (error) {
//       console.error("Login error:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   const handleForgotPassword = async () => {
//     if (!username) {
//       Alert.alert("Error", "Please enter your email to reset your password.");
//       return;
//     }

//     try {
//       const response = await fetch(
//         "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU", // Replace with your Firebase API Key
//         {
//           method: "POST",
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             requestType: "PASSWORD_RESET",
//             email: username,
//           }),
//         }
//       );

//       const result = await response.json();

//       if (response.ok) {
//         Alert.alert("Success", "Check your email for password reset instructions.");
//       } else if (result.error?.message === "EMAIL_NOT_FOUND") {
//         Alert.alert("Error", "Email not found. Please register first.");
//       } else {
//         Alert.alert("Error", result.error?.message || "Failed to send the email.");
//       }
//     } catch (error) {
//       console.error("Error sending reset email:", error);
//       Alert.alert("Error", "An error occurred. Please try again.");
//     }
//   };

//   return (
//     <ImageBackground style={styles.background}>
//       <View style={styles.container}>
//         <Text style={styles.title}>Login</Text>
//         <View style={styles.inputContainer}>
//           <Text style={styles.label}>
//             Email <Text style={styles.required}>*</Text>
//           </Text>
//           <TextInput
//             placeholder="Enter your email"
//             style={[styles.input, errors.username && styles.errorInput]}
//             value={username}
//             onChangeText={setUsername}
//           />
//           {errors.username && <Text style={styles.errorText}>{errors.username}</Text>}

//           <Text style={styles.label}>
//             Password <Text style={styles.required}>*</Text>
//           </Text>
//           <TextInput
//             placeholder="Enter your password"
//             style={[styles.input, errors.password && styles.errorInput]}
//             secureTextEntry
//             value={password}
//             onChangeText={setPassword}
//           />
//           {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

//           <TouchableOpacity style={styles.button} onPress={handleLogin}>
//             <Text style={styles.buttonText}>LOGIN</Text>
//           </TouchableOpacity>

//           <TouchableOpacity onPress={handleForgotPassword}>
//             <Text style={styles.forgotPassword}>Forgot Password?</Text>
//           </TouchableOpacity>
//         </View>
//       </View>
//     </ImageBackground>
//   );
// };

// const styles = StyleSheet.create({
//   background: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     width: "100%",
//     height: "100%",
//   },
//   container: {
//     backgroundColor: "rgba(255, 255, 255, 0.9)",
//     padding: 20,
//     borderRadius: 10,
//     width: "85%",
//     alignItems: "center",
//     borderColor: "#ddd",
//     borderWidth: 1,
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: "bold",
//     marginBottom: 15,
//   },
//   inputContainer: {
//     width: "100%",
//   },
//   label: {
//     fontSize: 16,
//     marginBottom: 5,
//   },
//   required: {
//     color: "red",
//   },
//   input: {
//     height: 45,
//     borderColor: "#ccc",
//     borderWidth: 1,
//     marginBottom: 10,
//     paddingHorizontal: 10,
//     borderRadius: 5,
//   },
//   errorInput: {
//     borderColor: "red",
//   },
//   errorText: {
//     color: "red",
//     fontSize: 12,
//     marginBottom: 5,
//   },
//   button: {
//     backgroundColor: "#5cb85c",
//     paddingVertical: 10,
//     borderRadius: 5,
//     marginBottom: 10,
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "white",
//     fontWeight: "bold",
//   },
//   forgotPassword: {
//     color: "blue",
//     textDecorationLine: "underline",
//     marginTop: 10,
//     textAlign: "center",
//   },
// });

// export default AdminLogin;




import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ImageBackground,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const AdminLogin = ({ navigation }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false); // 👁️ Password visibility state
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    let newErrors = {};
    let hasError = false;

    if (!username) {
      newErrors.username = "Email is required.";
      hasError = true;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
      newErrors.username = "Invalid email format.";
      hasError = true;
    }

    if (!password) {
      newErrors.password = "Password is required.";
      hasError = true;
    }

    setErrors(newErrors);
    return !hasError;
  };

  const handleLogin = async () => {
    if (!validateForm()) return;

    try {
      const response = await fetch(
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU",
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: username,
            password: password,
            returnSecureToken: true,
          }),
        }
      );

      const result = await response.json();
      console.log("API Response:", result);

      if (response.ok && result.idToken) {
        await AsyncStorage.setItem("idToken", result.idToken);
        await AsyncStorage.setItem("userId", result.localId);

        if (username === "211400125@gift.edu.pk") {
          Alert.alert("Success", "Logged in successfully as admin!");
          navigation.navigate("AdminDashboard", { idToken: result.idToken });
        } else {
          Alert.alert("Access Denied", "You are not authorized to access the admin dashboard.");
          navigation.navigate("UserDashboard");
        }
      } else {
        Alert.alert("Error", result.error?.message || "Invalid credentials.");
      }
    } catch (error) {
      console.error("Login error:", error);
      Alert.alert("Error", "Something went wrong. Please try again.");
    }
  };

  const handleForgotPassword = async () => {
    if (!username) {
      Alert.alert("Error", "Please enter your email to reset your password.");
      return;
    }

    try {
      const response = await fetch(
        "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU",
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            requestType: "PASSWORD_RESET",
            email: username,
          }),
        }
      );

      const result = await response.json();

      if (response.ok) {
        Alert.alert("Success", "Check your email for password reset instructions.");
      } else if (result.error?.message === "EMAIL_NOT_FOUND") {
        Alert.alert("Error", "Email not found. Please register first.");
      } else {
        Alert.alert("Error", result.error?.message || "Failed to send the email.");
      }
    } catch (error) {
      console.error("Error sending reset email:", error);
      Alert.alert("Error", "An error occurred. Please try again.");
    }
  };

  return (
    <ImageBackground style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>Login</Text>
        <View style={styles.inputContainer}>
          <Text style={styles.label}>
            Email <Text style={styles.required}>*</Text>
          </Text>
          <TextInput
            placeholder="Enter your email"
            style={[styles.input, errors.username && styles.errorInput]}
            value={username}
            onChangeText={setUsername}
          />
          {errors.username && <Text style={styles.errorText}>{errors.username}</Text>}

          <Text style={styles.label}>
            Password <Text style={styles.required}>*</Text>
          </Text>
          <View style={styles.passwordContainer}>
            <TextInput
              placeholder="Enter your password"
              style={[styles.input, styles.passwordInput, errors.password && styles.errorInput]}
              secureTextEntry={!showPassword} // 👁️ Toggles password visibility
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
              <Text>{showPassword ? "🙈" : "👁️"}</Text> {/* 👁️ Eye toggle icon */}
            </TouchableOpacity>
          </View>
          {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>LOGIN</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleForgotPassword}>
            <Text style={styles.forgotPassword}>Forgot Password?</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    height: "100%",
  },
  container: {
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    padding: 20,
    borderRadius: 10,
    width: "85%",
    alignItems: "center",
    borderColor: "#ddd",
    borderWidth: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 15,
  },
  inputContainer: {
    width: "100%",
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  required: {
    color: "red",
  },
  input: {
    height: 45,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
  },
  passwordInput: {
    flex: 1,
    paddingHorizontal: 10,
    height: 45,
  },
  eyeIcon: {
    padding: 10,
  },
  errorInput: {
    borderColor: "red",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginBottom: 5,
  },
  button: {
    backgroundColor: "#5cb85c",
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
  forgotPassword: {
    color: "blue",
    textDecorationLine: "underline",
    marginTop: 10,
    textAlign: "center",
  },
});

export default AdminLogin;
