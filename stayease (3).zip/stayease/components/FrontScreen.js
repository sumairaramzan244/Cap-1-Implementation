// import React from 'react';
// import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';

// export default function FrontScreen({ navigation }) {
//   return (
//     <View style={styles.container}>
//       <TouchableOpacity style={styles.logoContainer} onPress={() => navigation.navigate('UserRoleSelection')}>
//         <Image
//           source={require('../assets/Logo.png')} // Path to your logo
//           style={styles.backgroundLogo}
//           resizeMode="cover"
//         />
//         <Image
//           source={require('../assets/Logo.png')} // Path to your logo
//           style={styles.logo}
//           resizeMode="contain"
//         />
//       </TouchableOpacity>
//       <Text style={styles.title}>Welcome to StayEase</Text>
//       <Text style={styles.subtitle}>Unlock Comfort, Live with Ease</Text>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: 'lightblue', // Full blue background
//   },
//   logoContainer: {
//     width: 220,
//     height: 220,
//     justifyContent: 'center',
//     alignItems: 'center',
//     borderRadius: 110, // Circular shape for the container
//     overflow: 'hidden', // Ensures the image stays within the circle
//     backgroundColor: '#E2E8F0', // Light grayish-blue for contrast
//     marginBottom: 20,
//   },
//   backgroundLogo: {
//     ...StyleSheet.absoluteFillObject, // Covers the entire logoContainer
//     opacity: 0.1, // Fades the background logo for better visual clarity
//   },
//   logo: {
//     width: 150,
//     height: 150,
//     borderRadius: 110, // Makes the logo itself circular
//     position: 'absolute', // Ensures it stays centered
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: '#FFFFFF', // White text for contrast with the blue background
//     marginTop: 20,
//   },
//   subtitle: {
//     fontSize: 16,
//     color: 'white', // Light gray for a softer subtitle
//     marginTop: 10,
//   },
// });


import React, { useEffect } from 'react';
import { View, Image, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function FrontScreen({ navigation }) {
  // 5 seconds ke baad automatically next screen par navigate karne ke liye
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.navigate('UserRoleSelection');
    }, 5000); // 5000 milliseconds = 5 seconds

    // Cleanup function to clear the timer
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.logoContainer}
        onPress={() => navigation.navigate('UserRoleSelection')}
      >
        <Image
          source={require('../assets/Logo.png')} // Apne logo ka path daalein
          style={styles.backgroundLogo}
          resizeMode="cover"
        />
        <Image
          source={require('../assets/Logo.png')} // Apne logo ka path daalein
          style={styles.logo}
          resizeMode="contain"
        />
      </TouchableOpacity>
      <Text style={styles.title}>Welcome to StayEase</Text>
      <Text style={styles.subtitle}>Unlock Comfort , Live With Ease</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // backgroundColor: '#ADD8E6', // Light blue background
    backgroundColor:'#f9a7a7',
  },
  logoContainer: {
    width: 150,
    height: 150,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 150, // Circular shape for the containe
    overflow: 'hidden', // Ensures the image stays within the circle
    backgroundColor: '#E2E8F0', // Light grayish-blue for contrast
    marginBottom: 20,
  },
  backgroundLogo: {
    ...StyleSheet.absoluteFillObject, // Covers the entire logoContainer
    opacity: 0.1, // Fades the background logo for better visual clarity
  },
  logo: {
    width: 200,
    height: 200,
    borderRadius: 200, // Makes the logo itself circula
    position: 'absolute', // Ensures it stays centered
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white', // White text for contrast with the blue backgroun
    marginTop: 20,
  },
  subtitle: {
    fontSize: 16,
    color: 'white', // Light gray for a softer subtitle
    marginTop: 10,
  },
});