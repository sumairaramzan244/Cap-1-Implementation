




// import React, { useState } from 'react';
// import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

// const UserSelectRole = ({ navigation }) => {
//   const [selectedRole, setSelectedRole] = useState('');

//   // Function to handle role selection
//   const handleRoleSelect = (role) => {
//     setSelectedRole(role);
//     // Navigate based on the selected role
//     if (role === 'HomeScreen') {
//       navigation.navigate('HomeScreen'); // Navigate to Home screen for User
//     } else if (role === 'AdminLogin') {
//       navigation.navigate('AdminLogin'); // Navigate to AdminLogin screen for Admin
//     }
//   };

//   return (
//     <View style={styles.container}>
//       {/* Title */}
//       <Text style={styles.title}>Choose your role below</Text>

//       {/* Role Selection Cards */}
//       <View style={styles.cardContainer}>
//         <View style={styles.row}> 
//           {/* Admin Role Card */}
//           <TouchableOpacity
//             style={[styles.card, selectedRole === 'Admin' && styles.selectedCard]}
//             onPress={() => handleRoleSelect('AdminLogin')}
//           >
//             <Image source={require('../assets/admin.png')} style={styles.icon} />
//             <Text style={styles.cardText}>Admin</Text>
//           </TouchableOpacity>
//         </View>

//         <View style={styles.row}> 
//           {/* User Role Card */}
//           <TouchableOpacity
//             style={[styles.card, selectedRole === 'User' && styles.selectedCard]}
//             onPress={() => handleRoleSelect('HomeScreen')}
//           >
//             <Image source={require('../assets/user.png')} style={styles.icon} />
//             <Text style={styles.cardText}>User</Text>
//           </TouchableOpacity>
//         </View>
//       </View>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'flex-start',
//     alignItems: 'center',
//     backgroundColor: '#f9a7a7', // Light blue background
//     paddingVertical: 40, // Adjusted padding to move title to top
//   },
//   title: {
//     fontSize: 26, // Slightly larger font size
//     fontWeight: 'bold',
//     color: '#FFFFFF', // White text for contrast with the blue background
//     marginBottom: 20, // Reduced margin to bring content closer
//   },
//   cardContainer: {
//     flexDirection: 'column', // Changed to column to stack rows
//     alignItems: 'center',
//     marginTop: 20,
//   },
//   row: {
//     flexDirection: 'row',
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginBottom: 20, // Space between rows
//   },
//   card: {
//     backgroundColor: 'white', // Light grayish-blue for the cards
//     borderRadius: 15, // Adjusted border radius
//     padding: 5, // Reduced padding to decrease excessive spacing
//     width: '100%', // Adjusted width to fit within row
//     justifyContent: 'center',
//     alignItems: 'center',
//     shadowColor: '#000', // Add shadow for a slight 3D effect
//     shadowOffset: { width: 0, height: 3 },
//     shadowOpacity: 0.1,
//     shadowRadius: 4,
//     elevation: 4, // Reduced shadow elevation
//     marginHorizontal: 8,
//     height: '100', // Adjusted height for better proportions
//   },
//   selectedCard: {
//     borderWidth: 3,
//     borderColor: '#6A4CFF', // Highlight selected card with purple border
//   },
//   icon: {
//     width: 100, // Adjusted icon size
//     height: 100,
//     marginBottom: 10, // Reduced spacing
//     borderRadius: 32, // Optional: Make image round for better presentation
//   },
//   cardText: {
//     color: 'black', // Dark text for card content
//     fontSize: 25, // Slightly adjusted font size
//     fontWeight: 'bold',
//   },
// });

// export default UserSelectRole;


















import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

const UserSelectRole = ({ navigation }) => {
  const [selectedRole, setSelectedRole] = useState('');

  const handleRoleSelect = (role) => {
    setSelectedRole(role);
    if (role === 'Login') {
      navigation.navigate('Login');
    } else if (role === 'AdminLogin') {
      navigation.navigate('AdminLogin');
    }
  };

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>Choose your role below</Text>

      {/* Role Selection Cards */}
      <View style={styles.cardContainer}>
        {/* Admin Role Card */}
        <TouchableOpacity
          style={[styles.card, selectedRole === 'AdminLogin' && styles.selectedCard]}
          onPress={() => handleRoleSelect('AdminLogin')}
        >
          <Image source={require('../assets/admin.png')} style={styles.icon} />
          <Text style={styles.cardText}>Admin</Text>
        </TouchableOpacity>

        {/* User Role Card */}
        <TouchableOpacity
          style={[styles.card, selectedRole === 'Login' && styles.selectedCard]}
          onPress={() => handleRoleSelect('Login')}
        >
          <Image source={require('../assets/user.png')} style={styles.icon} />
          <Text style={styles.cardText}>Landlord</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', // Center content properly
    alignItems: 'center',
    backgroundColor: '#f9a7a7', // Keeping original color
    paddingVertical: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 20, // Slightly reduced spacing
  },
  cardContainer: {
    width: '100%',
    alignItems: 'center',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12, // Slightly rounded corners
    paddingVertical: 15, // More compact padding
    width: '80%', // Proper width to avoid excess space
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 4,
    marginBottom: 15, // Reduced margin between cards
    flexDirection: 'column', // Stack image and text properly
    justifyContent: 'center',
  },
  selectedCard: {
    borderWidth: 2,
    borderColor: '#FF6347', // Slight highlight on selection
  },
  icon: {
    width: 70, // Slightly smaller icon for better layout
    height: 70,
    marginBottom: 8, // Adjusted spacing
  },
  cardText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default UserSelectRole;
