

// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   ScrollView,
//   Image,
//   TextInput,
//   TouchableOpacity,
//   Modal,
// } from 'react-native';
// import { FontAwesome, Ionicons } from '@expo/vector-icons';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Notificationlandlord from './Notificationlandlord'; // Placeholder for NotificationsScreen

// function HomeScreen({ navigation }) {
//   const [isModalVisible, setIsModalVisible] = useState(false);

//   const toggleModal = () => {
//     setIsModalVisible(!isModalVisible);
//   };

//   const categories = [
//     { label: 'Rooms', icon: 'home' },
//     { label: 'Flats', icon: 'building' },
//     { label: 'Apartments', icon: 'apartment' },
//     { label: 'Budget', icon: 'dollar' },
//     { label: 'Shared Rooms', icon: 'users' },
//   ];

//   const [filteredProperties, setFilteredProperties] = useState([1, 2, 3, 4]);

//   return (
//     <View style={styles.container}>
//       {/* Top Navigation Bar */}
//       <View style={styles.navBar}>
//         <Image source={require('../assets/Logo.png')} style={styles.logo} />
//         <View style={styles.navOptions}>
//           <Text style={styles.navOption}>Stay</Text>
//           <Text style={styles.navOption}>Ease</Text>
//         </View>
//         <TouchableOpacity onPress={toggleModal}>
//           <FontAwesome name="user-circle" size={24} color="black" />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar */}
//       <View style={styles.searchBar}>
//         <TextInput style={styles.input} placeholder="Location" />
//         <TouchableOpacity style={styles.searchButton}>
//           <FontAwesome name="search" size={20} color="#fff" />
//         </TouchableOpacity>
//       </View>

//       {/* Category Filter */}
//       <View style={styles.filterContainer}>
//         <Text style={styles.filterLabel}>Filter by Category</Text>
//         <View style={styles.categoryList}>
//           {categories.map((category, index) => (
//             <TouchableOpacity key={index} style={styles.categoryItem}>
//               <FontAwesome name={category.icon} size={20} color="black" />
//               <Text style={styles.categoryText}>{category.label}</Text>
//             </TouchableOpacity>
//           ))}
//         </View>
//       </View>

//       {/* Property Cards */}
//       <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.propertyList}>
//         {filteredProperties.map((_, index) => (
//           <View key={index} style={styles.propertyCard}>
//             <Image source={require('../assets/r1.jpg')} style={styles.propertyImage} />
//             <Text style={styles.tag}>Guest favorite</Text>
//             <View style={styles.propertyInfo}>
//               <Text style={styles.propertyLocation}>City, Country</Text>
//               <Text style={styles.propertyDescription}>Stay description</Text>
//               <Text style={styles.propertyDates}>Jan 27 - Feb 1</Text>
//               <View style={styles.rating}>
//                 <FontAwesome name="star" size={14} color="gold" />
//                 <Text style={styles.ratingText}>4.89</Text>
//               </View>
//             </View>
//           </View>
//         ))}
//       </ScrollView>

//       {/* Add Property Button */}
//       <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('Login')}>
//         <FontAwesome name="plus-circle" size={24} color="white" />
//         <Text style={styles.addPropertyText}>Add Property</Text>
//       </TouchableOpacity>

//       {/* Modal */}
//       <Modal visible={isModalVisible} transparent animationType="slide">
//         <View style={styles.modalContainer}>
//           <View style={styles.modalContent}>
//             <Text style={styles.modalTitle}>User Profile</Text>
//             <Text style={styles.modalText}>Name: John Doe</Text>
//             <Text style={styles.modalText}>Email: john.doe@example.com</Text>
//             <Text style={styles.modalText}>Phone: +123456789</Text>
//             <TouchableOpacity style={styles.closeButton} onPress={toggleModal}>
//               <Text style={styles.closeButtonText}>Close</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </View>
//   );
// }

// // Tab Navigator
// const Tab = createBottomTabNavigator();

// const HomeScreenWithTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         tabBarIcon: ({ color }) => {
//           let iconName;
//           if (route.name === 'Home') {
//             iconName = 'home-outline';
//           } else if (route.name === 'Notification') {
//             iconName = 'notifications-outline';
//           }
//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//         tabBarActiveTintColor: '#4A90E2',
//         tabBarInactiveTintColor: '#888',
//         tabBarStyle: {
//           backgroundColor: '#ffffff',
//           height: 65,
//           paddingBottom: 10,
//           borderTopWidth: 1,
//           borderTopColor: '#e0e0e0',
//         },
//       })}
//     >
//       <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
//       <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
//     </Tab.Navigator>
//   );
// };

// export default HomeScreenWithTabs;

// // Styles
// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
//   navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   logo: { width: 100, height: 30, resizeMode: 'contain' },
//   navOptions: { flexDirection: 'row', alignItems: 'center' },
//   navOption: { fontSize: 16, marginHorizontal: 10, fontWeight: 'bold', color: '#000' },
//   searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
//   input: { flex: 1, padding: 10, backgroundColor: '#fff', borderRadius: 5, borderWidth: 1, borderColor: '#ddd' },
//   searchButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5, marginLeft: 5 },
//   filterContainer: { marginBottom: 20 },
//   filterLabel: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
//   categoryList: { flexDirection: 'row' },
//   categoryItem: { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 10 },
//   propertyList: { marginVertical: 10 },
//   propertyCard: { width: 200, backgroundColor: '#fff', borderRadius: 8, marginHorizontal: 10 },
//   propertyImage: { width: '100%', height: 120 },
//   tag: { position: 'absolute', top: 10, left: 10, backgroundColor: '#fff', padding: 5, borderRadius: 5 },
//   propertyInfo: { padding: 10 },
//   propertyLocation: { fontSize: 14, fontWeight: 'bold', color: '#333' },
//   propertyDescription: { fontSize: 12, color: '#666', marginVertical: 5 },
//   propertyDates: { fontSize: 12, color: '#888' },
//   rating: { flexDirection: 'row', alignItems: 'center', marginTop: 5 },
//   ratingText: { fontSize: 12, marginLeft: 5, color: '#666' },
//   addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
//   addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
//   modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.5)' },
//   modalContent: { width: '80%', backgroundColor: '#fff', padding: 20, borderRadius: 10 },
//   modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
//   modalText: { fontSize: 16, marginBottom: 10, color: '#333' },
//   closeButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5 },
//   closeButtonText: { color: '#fff', fontWeight: 'bold', textAlign: 'center' },
// });




















// import React, { useState,useEffect } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   ScrollView,
//   Image,
//   TextInput,
//   TouchableOpacity,
//   Modal,Alert
// } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';

// import { Video } from 'expo-av';

// import { FontAwesome, Ionicons } from '@expo/vector-icons';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Notificationlandlord from './Notificationlandlord'; // Placeholder for NotificationsScreen

// function HomeScreen({ navigation }) {
//   const [isModalVisible, setIsModalVisible] = useState(false);
//   const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com/'; // Define your Firebase database URL
// const [userId, setUserId] = useState(null);
// const fetchUserProperties = async (userId) => {
//   if (!userId) {
//     Alert.alert('Error', 'User ID is missing. Please log in.');
//     return;
//   }

//   try {
//     // Get the idToken from AsyncStorage (ensure you store it when user logs in)
//     const idToken = await AsyncStorage.getItem('idToken');
//     if (!idToken) {
//       throw new Error('No authentication token found');
//     }
// const response = await fetch(`${databaseUrl}/addProperty/${userId}.json?auth=${idToken}`);

//     console.log('Response status:',response.status); // Log the status code

//     if (!response.ok) {
//       throw new Error('Failed to fetch properties');
//     }

//     const data = await response.json();
//     console.log('Fetched Data:', data); // Log the fetched data

//     if (!data) {
//       throw new Error('No data found for this user');
//     }

//     const properties = Object.values(data); // Convert object to array
//     setFilteredProperties(properties); // Update state with the fetched properties

//   } catch (error) {
//     console.error('Error fetching user properties:', error);
//     Alert.alert('Error', error.message || 'Could not fetch properties. Please try again.');
//   }
// };

    
//   useEffect(() => {
//     const checkUserAuthentication = async () => {
//       try {
//         const storedUserId = await AsyncStorage.getItem('userId');
//         console.log('Stored userId:', storedUserId);  // Log the userId

//         if (storedUserId) {
//           setUserId(storedUserId);  // Set userId from AsyncStorage
//           fetchUserProperties(storedUserId);  // Fetch properties based on userId
//         } else {
//           Alert.alert('Error', 'User is not authenticated. Please log in.');
//           navigation.navigate('Login');  // Navigate to login if no userId
//         }
//       } catch (error) {
//         console.error('Error fetching authentication details:', error);
//         Alert.alert('Error', 'Failed to retrieve authentication details.');
//       }
//     };

//     checkUserAuthentication(); // Call function to check authentication
//   }, [navigation]);

//   const toggleModal = () => {
//     setIsModalVisible(!isModalVisible);
//   };

//   const categories = [
//     { label: 'Rooms', icon: 'home' },
//     { label: 'Flats', icon: 'building' },
//     { label: 'Apartments', icon: 'apartment' },
//     { label: 'Budget', icon: 'dollar' },
//     { label: 'Shared Rooms', icon: 'users' },
//   ];

//   const [filteredProperties, setFilteredProperties] = useState([1, 2, 3, 4]);

//   return (
//     <View style={styles.container}>
//       {/* Top Navigation Bar */}
//       <View style={styles.navBar}>
//         <Image source={require('../assets/Logo.png')} style={styles.logo} />
//         <View style={styles.navOptions}>
//           <Text style={styles.navOption}>Stay</Text>
//           <Text style={styles.navOption}>Ease</Text>
//         </View>
//         <TouchableOpacity onPress={toggleModal}>
//           <FontAwesome name="user-circle" size={24} color="black" />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar */}
//       <View style={styles.searchBar}>
//         <TextInput style={styles.input} placeholder="Location" />
//         <TouchableOpacity style={styles.searchButton}>
//           <FontAwesome name="search" size={20} color="#fff" />
//         </TouchableOpacity>
//       </View>

//       {/* Category Filter */}
//       <View style={styles.filterContainer}>
//         <Text style={styles.filterLabel}>Filter by Category</Text>
//         <View style={styles.categoryList}>
//           {categories.map((category, index) => (
//             <TouchableOpacity key={index} style={styles.categoryItem}>
//               <FontAwesome name={category.icon} size={20} color="black" />
//               <Text style={styles.categoryText}>{category.label}</Text>
//             </TouchableOpacity>
//           ))}
//         </View>
//       </View>

//       {/* Property Cards */}
// {filteredProperties.map((property, index) => (
//   <View key={index} style={styles.propertyCard}>
//     {/* Image */}
//     console.log(property.images ? property.images[0] : 'No Image URL');

//     <Image 
//   source={{ uri: property.images ? property.images[0] : 'default-image-url' }} 
//   style={styles.propertyImage} 
// />

    
//     {/* Title */}
//     <Text style={styles.propertyTitle}>{property.propertyTitle}</Text>
    
//     {/* Description */}
//     <Text style={styles.propertyDescription}>{property.description}</Text>
    
//     {/* Price */}
//     <Text style={styles.propertyPrice}>Price: {property.price}</Text>
    
//     {/* Location */}
//     <Text style={styles.propertyLocation}>Location: {property.propertyLocation}</Text>

//     {/* Video */}
// {property.videos && property.videos.length > 0 ? (
//   <Video
//     source={{ uri: property.videos[0] }}
//     style={styles.videoContainer}
//     useNativeControls
//     resizeMode="contain"
//     isLooping
//   />
// ) : (
//   <Text style={styles.propertyVideo}>No Video Available</Text>
// )}


//     {/* Additional Information */}
//     <Text style={styles.propertySubmittedAt}>
//       Submitted At: {new Date(property.submittedAt).toLocaleString()}
//     </Text>
//   </View>
// ))}

//       {/* Add Property Button */}
//       <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('Login')}>
//         <FontAwesome name="plus-circle" size={24} color="white" />
//         <Text style={styles.addPropertyText}>Add Property</Text>
//       </TouchableOpacity>

//       {/* Modal */}
//       <Modal visible={isModalVisible} transparent animationType="slide">
//         <View style={styles.modalContainer}>
//           <View style={styles.modalContent}>
//             <Text style={styles.modalTitle}>User Profile</Text>
//             <Text style={styles.modalText}>Name: John Doe</Text>
//             <Text style={styles.modalText}>Email: john.doe@example.com</Text>
//             <Text style={styles.modalText}>Phone: +123456789</Text>
//             <TouchableOpacity style={styles.closeButton} onPress={toggleModal}>
//               <Text style={styles.closeButtonText}>Close</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </View>
//   );
// }

// // Tab Navigator
// const Tab = createBottomTabNavigator();

// const HomeScreenWithTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         tabBarIcon: ({ color }) => {
//           let iconName;
//           if (route.name === 'Home') {
//             iconName = 'home-outline';
//           } else if (route.name === 'Notification') {
//             iconName = 'notifications-outline';
//           }
//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//         tabBarActiveTintColor: '#4A90E2',
//         tabBarInactiveTintColor: '#888',
//         tabBarStyle: {
//           backgroundColor: '#ffffff',
//           height: 65,
//           paddingBottom: 10,
//           borderTopWidth: 1,
//           borderTopColor: '#e0e0e0',
//         },
//       })}
//     >
//       <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
//       <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
//     </Tab.Navigator>
//   );
// };

// export default HomeScreenWithTabs;

// // Styles
// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
//   navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   logo: { width: 100, height: 30, resizeMode: 'contain' },
//   navOptions: { flexDirection: 'row', alignItems: 'center' },
//   navOption: { fontSize: 16, marginHorizontal: 10, fontWeight: 'bold', color: '#000' },
//   searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
//   input: { flex: 1, padding: 10, backgroundColor: '#fff', borderRadius: 5, borderWidth: 1, borderColor: '#ddd' },
//   searchButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5, marginLeft: 5 },
//   filterContainer: { marginBottom: 20 },
//   filterLabel: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
//   categoryList: { flexDirection: 'row' },
//   categoryItem: { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 10 },
 
//    propertyCard: {
//     width: 200, 
//     backgroundColor: '#fff', 
//     borderRadius: 8, 
//     marginHorizontal: 10, 
//     padding: 10,
//   },
//   propertyImage: {
//     width: '100%', 
//     height: 120, 
//     borderRadius: 5,
//   },
//   propertyTitle: {
//     fontSize: 16, 
//     fontWeight: 'bold', 
//     color: '#333',
//     marginTop: 10,
//   },
//   propertyDescription: {
//     fontSize: 12, 
//     color: '#666',
//     marginVertical: 5,
//   },
//   propertyPrice: {
//     fontSize: 14, 
//     color: '#FF5A5F', 
//     fontWeight: 'bold',
//   },
//   propertyLocation: {
//     fontSize: 12, 
//     color: '#888',
//   },
//   propertyVideo: {
//     fontSize: 12, 
//     color: '#333',
//     marginTop: 5,
//   },
//   propertySubmittedAt: {
//     fontSize: 10, 
//     color: '#aaa',
//     marginTop: 5,
//   },
 
//   addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
//   addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
//   modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.5)' },
//   modalContent: { width: '80%', backgroundColor: '#fff', padding: 20, borderRadius: 10 },
//   modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
//   modalText: { fontSize: 16, marginBottom: 10, color: '#333' },
//   closeButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5 },
//   closeButtonText: { color: '#fff', fontWeight: 'bold', textAlign: 'center' },
// });
























// import React, { useState,useEffect } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   ScrollView,
//   Image,
//   TextInput,
//   TouchableOpacity,
//   Modal,Alert
// } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';

// import { Video } from 'expo-av';

// import { FontAwesome, Ionicons } from '@expo/vector-icons';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Notificationlandlord from './Notificationlandlord'; // Placeholder for NotificationsScreen

// function HomeScreen({ navigation }) {
//   const [isModalVisible, setIsModalVisible] = useState(false);
//   const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com/'; // Define your Firebase database URL
// const [userId, setUserId] = useState(null);
// const fetchUserProperties = async (userId) => {
//   if (!userId) {
//     Alert.alert('Error', 'User ID is missing. Please log in.');
//     return;
//   }

//   try {
//     // Get the idToken from AsyncStorage (ensure you store it when user logs in)
//     const idToken = await AsyncStorage.getItem('idToken');
//     if (!idToken) {
//       throw new Error('No authentication token found');
//     }
// const response = await fetch(`${databaseUrl}/addProperty/${userId}.json?auth=${idToken}`);

//     console.log('Response status:',response.status); // Log the status code

//     if (!response.ok) {
//       throw new Error('Failed to fetch properties');
//     }

//     const data = await response.json();
//     console.log('Fetched Data:', data); // Log the fetched data

//     if (!data) {
//       throw new Error('No data found for this user');
//     }

//     const properties = Object.values(data); // Convert object to array
//     setFilteredProperties(properties); // Update state with the fetched properties

//   } catch (error) {
//     console.error('Error fetching user properties:', error);
//     Alert.alert('Error', error.message || 'Could not fetch properties. Please try again.');
//   }
// };

    
//   useEffect(() => {
//     const checkUserAuthentication = async () => {
//       try {
//         const storedUserId = await AsyncStorage.getItem('userId');
//         console.log('Stored userId:', storedUserId);  // Log the userId

//         if (storedUserId) {
//           setUserId(storedUserId);  // Set userId from AsyncStorage
//           fetchUserProperties(storedUserId);  // Fetch properties based on userId
//         } else {
//           Alert.alert('Error', 'User is not authenticated. Please log in.');
//           navigation.navigate('Login');  // Navigate to login if no userId
//         }
//       } catch (error) {
//         console.error('Error fetching authentication details:', error);
//         Alert.alert('Error', 'Failed to retrieve authentication details.');
//       }
//     };

//     checkUserAuthentication(); // Call function to check authentication
//   }, [navigation]);

//   const toggleModal = () => {
//     setIsModalVisible(!isModalVisible);
//   };

//   const categories = [
//     { label: 'Rooms', icon: 'home' },
//     { label: 'Flats', icon: 'building' },
//     { label: 'Apartments', icon: 'apartment' },
//     { label: 'Budget', icon: 'dollar' },
//     { label: 'Shared Rooms', icon: 'users' },
//   ];

//   const [filteredProperties, setFilteredProperties] = useState([1, 2, 3, 4]);

//   return (
//     <View style={styles.container}>
//       {/* Top Navigation Bar */}
//       <View style={styles.navBar}>
//         <Image source={require('../assets/Logo.png')} style={styles.logo} />
//         <View style={styles.navOptions}>
//           <Text style={styles.navOption}>Stay</Text>
//           <Text style={styles.navOption}>Ease</Text>
//         </View>
//         <TouchableOpacity onPress={toggleModal}>
//           <FontAwesome name="user-circle" size={24} color="black" />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar */}
//       <View style={styles.searchBar}>
//         <TextInput style={styles.input} placeholder="Location" />
//         <TouchableOpacity style={styles.searchButton}>
//           <FontAwesome name="search" size={20} color="#fff" />
//         </TouchableOpacity>
//       </View>

//       {/* Category Filter */}
//       <View style={styles.filterContainer}>
//         <Text style={styles.filterLabel}>Filter by Category</Text>
//         <View style={styles.categoryList}>
//           {categories.map((category, index) => (
//             <TouchableOpacity key={index} style={styles.categoryItem}>
//               <FontAwesome name={category.icon} size={20} color="black" />
//               <Text style={styles.categoryText}>{category.label}</Text>
//             </TouchableOpacity>
//           ))}
//         </View>
//       </View>

//       {/* Property Cards */}
// {filteredProperties.map((property, index) => (
//   <View key={index} style={styles.propertyCard}>
//     {/* Image */}
//     console.log(property.images ? property.images[0] : 'No Image URL');

//     <Image 
//   source={{ uri: property.images ? property.images[0] : 'default-image-url' }} 
//   style={styles.propertyImage} 
// />

    
//     {/* Title */}
//     <Text style={styles.propertyTitle}>{property.propertyTitle}</Text>
    
//     {/* Description */}
//     <Text style={styles.propertyDescription}>{property.description}</Text>
    
//     {/* Price */}
//     <Text style={styles.propertyPrice}>Price: {property.price}</Text>
    
//     {/* Location */}
//     <Text style={styles.propertyLocation}>Location: {property.propertyLocation}</Text>

//     {/* Video */}
// {property.videos && property.videos.length > 0 ? (
//   <Video
//     source={{ uri: property.videos[0] }}
//     style={styles.videoContainer}
//     useNativeControls
//     resizeMode="contain"
//     isLooping
//   />
// ) : (
//   <Text style={styles.propertyVideo}>No Video Available</Text>
// )}


//     {/* Additional Information */}
//     <Text style={styles.propertySubmittedAt}>
//       Submitted At: {new Date(property.submittedAt).toLocaleString()}
//     </Text>
//   </View>
// ))}

//       {/* Add Property Button */}
//       <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('Login')}>
//         <FontAwesome name="plus-circle" size={24} color="white" />
//         <Text style={styles.addPropertyText}>Add Property</Text>
//       </TouchableOpacity>

//       {/* Modal */}
//       <Modal visible={isModalVisible} transparent animationType="slide">
//         <View style={styles.modalContainer}>
//           <View style={styles.modalContent}>
//             <Text style={styles.modalTitle}>User Profile</Text>
//             <Text style={styles.modalText}>Name: John Doe</Text>
//             <Text style={styles.modalText}>Email: john.doe@example.com</Text>
//             <Text style={styles.modalText}>Phone: +123456789</Text>
//             <TouchableOpacity style={styles.closeButton} onPress={toggleModal}>
//               <Text style={styles.closeButtonText}>Close</Text>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </View>
//   );
// }

// // Tab Navigator
// const Tab = createBottomTabNavigator();

// const HomeScreenWithTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         tabBarIcon: ({ color }) => {
//           let iconName;
//           if (route.name === 'Home') {
//             iconName = 'home-outline';
//           } else if (route.name === 'Notification') {
//             iconName = 'notifications-outline';
//           }
//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//         tabBarActiveTintColor: '#4A90E2',
//         tabBarInactiveTintColor: '#888',
//         tabBarStyle: {
//           backgroundColor: '#ffffff',
//           height: 65,
//           paddingBottom: 10,
//           borderTopWidth: 1,
//           borderTopColor: '#e0e0e0',
//         },
//       })}
//     >
//       <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
//       <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
//     </Tab.Navigator>
//   );
// };

// export default HomeScreenWithTabs;

// // Styles
// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
//   navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   logo: { width: 100, height: 30, resizeMode: 'contain' },
//   navOptions: { flexDirection: 'row', alignItems: 'center' },
//   navOption: { fontSize: 16, marginHorizontal: 10, fontWeight: 'bold', color: '#000' },
//   searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
//   input: { flex: 1, padding: 10, backgroundColor: '#fff', borderRadius: 5, borderWidth: 1, borderColor: '#ddd' },
//   searchButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5, marginLeft: 5 },
//   filterContainer: { marginBottom: 20 },
//   filterLabel: { fontSize: 16, fontWeight: 'bold', marginBottom: 10 },
//   categoryList: { flexDirection: 'row' },
//   categoryItem: { flexDirection: 'row', alignItems: 'center', padding: 10, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 10 },
 
//    propertyCard: {
//     width: 200, 
//     backgroundColor: '#fff', 
//     borderRadius: 8, 
//     marginHorizontal: 10, 
//     padding: 10,
//   },
//   propertyImage: {
//     width: '100%', 
//     height: 120, 
//     borderRadius: 5,
//   },
//   propertyTitle: {
//     fontSize: 16, 
//     fontWeight: 'bold', 
//     color: '#333',
//     marginTop: 10,
//   },
//   propertyDescription: {
//     fontSize: 12, 
//     color: '#666',
//     marginVertical: 5,
//   },
//   propertyPrice: {
//     fontSize: 14, 
//     color: '#FF5A5F', 
//     fontWeight: 'bold',
//   },
//   propertyLocation: {
//     fontSize: 12, 
//     color: '#888',
//   },
//   propertyVideo: {
//     fontSize: 12, 
//     color: '#333',
//     marginTop: 5,
//   },
//   propertySubmittedAt: {
//     fontSize: 10, 
//     color: '#aaa',
//     marginTop: 5,
//   },
 
//   addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
//   addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
//   modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.5)' },
//   modalContent: { width: '80%', backgroundColor: '#fff', padding: 20, borderRadius: 10 },
//   modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
//   modalText: { fontSize: 16, marginBottom: 10, color: '#333' },
//   closeButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5 },
//   closeButtonText: { color: '#fff', fontWeight: 'bold', textAlign: 'center' },
// });



// import React, { useState, useEffect } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   Image,
//   TextInput,
//   TouchableOpacity,
//   Alert,ScrollView
// } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { Video } from 'expo-av';
// import { FontAwesome, Ionicons } from '@expo/vector-icons';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Notificationlandlord from './Notificationlandlord';
// import LandlordProfile from './LandlordProfile'; // Import the LandlordProfile screen

// function HomeScreen({ navigation }) {
//   const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com/';
//   const [userId, setUserId] = useState(null);
//   const [filteredProperties, setFilteredProperties] = useState([]);

//   const fetchUserProperties = async (userId) => {
//     if (!userId) {
//       Alert.alert('Error', 'User ID is missing. Please log in.');
//       return;
//     }

//     try {
//       const idToken = await AsyncStorage.getItem('idToken');
//       if (!idToken) {
//         throw new Error('No authentication token found');
//       }
//       const response = await fetch(`${databaseUrl}/addProperty/${userId}.json?auth=${idToken}`);
//       if (!response.ok) {
//         throw new Error('Failed to fetch properties');
//       }
//       const data = await response.json();
//       if (!data) {
//         throw new Error('No data found for this user');
//       }
//       const properties = Object.values(data);
//       setFilteredProperties(properties);
//     } catch (error) {
//       console.error('Error fetching user properties:', error);
//       Alert.alert('Error', error.message || 'Could not fetch properties. Please try again.');
//     }
//   };

//   useEffect(() => {
//     const checkUserAuthentication = async () => {
//       try {
//         const storedUserId = await AsyncStorage.getItem('userId');
//         if (storedUserId) {
//           setUserId(storedUserId);
//           fetchUserProperties(storedUserId);
//         } else {
//           Alert.alert('Error', 'User is not authenticated. Please log in.');
//           navigation.navigate('Login');
//         }
//       } catch (error) {
//         console.error('Error fetching authentication details:', error);
//         Alert.alert('Error', 'Failed to retrieve authentication details.');
//       }
//     };
//     checkUserAuthentication();
//   }, [navigation]);

//   return (
//     <View style={styles.container}>
//       {/* Top Navigation Bar */}
//       <View style={styles.navBar}>
//         <Image source={require('../assets/Logo.png')} style={styles.logo} />
//         <View style={styles.navOptions}>
//           <Text style={styles.navOption}>Stay</Text>
//           <Text style={styles.navOption}>Ease</Text>
//         </View>
//         <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
//           <FontAwesome name="user-circle" size={24} color="black" />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar */}
//       <View style={styles.searchBar}>
//         <TextInput style={styles.input} placeholder="Location" />
//         <TouchableOpacity style={styles.searchButton}>
//           <FontAwesome name="search" size={20} color="#fff" />
//         </TouchableOpacity>
//       </View>

//       {/* Property Cards */}
//      <ScrollView>
//         {filteredProperties.map((property, index) => (
//           <View key={index} style={styles.propertyCard}>

//             {/* ✅ Fixed Image Display */}
//             {property.images && property.images.length > 0 ? (
//               <ScrollView horizontal>
//                 {property.images.map((img, imgIndex) => (
//                   <Image key={imgIndex} source={{ uri: img }} style={styles.propertyImage} />
//                 ))}
//               </ScrollView>
//             ) : (
//               <Text style={styles.propertyVideo}>No Images Available</Text>
//             )}

//             {/* ✅ Fixed Video Display */}
//             {property.videos && property.videos.length > 0 ? (
//               <ScrollView horizontal>
//                 {property.videos.map((videoUrl, videoIndex) => (
//                   <Video
//                     key={videoIndex}
//                     source={{ uri: videoUrl }}
//                     style={styles.videoContainer}
//                     useNativeControls
//                     resizeMode="contain"
//                     isLooping
//                   />
//                 ))}
//               </ScrollView>
//             ) : (
//               <Text style={styles.propertyVideo}>No Video Available</Text>
//             )}

//             <Text style={styles.propertyTitle}>{property.propertyTitle}</Text>
//             <Text style={styles.propertyDescription}>{property.description}</Text>
//             <Text style={styles.propertyPrice}>Price: {property.price}</Text>
//             <Text style={styles.propertyLocation}>Location: {property.propertyLocation}</Text>

//             <Text style={styles.propertySubmittedAt}>
//               Submitted At: {new Date(property.submittedAt).toLocaleString()}
//             </Text>
//           </View>
//         ))}
//       </ScrollView>

//       {/* Add Property Button */}
//       <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('AddPropertyVerification')}>
//         <FontAwesome name="plus-circle" size={24} color="white" />
//         <Text style={styles.addPropertyText}>Add Property</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }

// // Tab Navigator
// const Tab = createBottomTabNavigator();

// const HomeScreenWithTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         tabBarIcon: ({ color }) => {
//           let iconName;
//           if (route.name === 'Home') {
//             iconName = 'home-outline';
//           } else if (route.name === 'Notification') {
//             iconName = 'notifications-outline';
//           } else if (route.name === 'Profile') {
//             iconName = 'person-outline';
//           }
//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//         tabBarActiveTintColor: '#4A90E2',
//         tabBarInactiveTintColor: '#888',
//         tabBarStyle: {
//           backgroundColor: '#ffffff',
//           height: 65,
//           paddingBottom: 10,
//           borderTopWidth: 1,
//           borderTopColor: '#e0e0e0',
//         },
//       })}
//     >
//       <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
//       <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
//       <Tab.Screen name="Profile" component={LandlordProfile} options={{ headerShown: false }} />
//     </Tab.Navigator>
//   );
// };
// // Styles
// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
//   navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   logo: { width: 100, height: 30, resizeMode: 'contain' },
//   navOptions: { flexDirection: 'row', alignItems: 'center' },
//   navOption: { fontSize: 16, marginHorizontal: 10, fontWeight: 'bold', color: '#000' },
//   searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
//   input: { flex: 1, padding: 10, backgroundColor: '#fff', borderRadius: 5, borderWidth: 1, borderColor: '#ddd' },
//   searchButton: { backgroundColor: '#ff5a5f', padding: 10, borderRadius: 5, marginLeft: 5 },
 
//    propertyCard: {
//     width: 200, 
//     backgroundColor: '#fff', 
//     borderRadius: 8, 
//     marginHorizontal: 10, 
//     padding: 10,
//   },
//   propertyImage: {
//     width: '100%', 
//     height: 120, 
//     borderRadius: 5,
//   },
//   propertyTitle: {
//     fontSize: 16, 
//     fontWeight: 'bold', 
//     color: '#333',
//     marginTop: 10,
//   },
//   propertyDescription: {
//     fontSize: 12, 
//     color: '#666',
//     marginVertical: 5,
//   },
//   propertyPrice: {
//     fontSize: 14, 
//     color: '#FF5A5F', 
//     fontWeight: 'bold',
//   },
//   propertyLocation: {
//     fontSize: 12, 
//     color: '#888',
//   },
//   propertyVideo: {
//     fontSize: 12, 
//     color: '#333',
//     marginTop: 5,
//   },
//   propertySubmittedAt: {
//     fontSize: 10, 
//     color: '#aaa',
//     marginTop: 5,
//   },
 
//   addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
//   addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
 
// });


// export default HomeScreenWithTabs;













// import React, { useState, useEffect } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   Image,
//   TextInput,
//   TouchableOpacity,
//   Alert, ScrollView
// } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { Video } from 'expo-av';
// import { FontAwesome, Ionicons } from '@expo/vector-icons';
// import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
// import Notificationlandlord from './Notificationlandlord';
// import LandlordProfile from './LandlordProfile'; // Import the LandlordProfile screen

// function HomeScreen({ navigation }) {
//   const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com/';
//   const [userId, setUserId] = useState(null);
//   const [filteredProperties, setFilteredProperties] = useState([]);

//   const fetchUserProperties = async (userId) => {
//     if (!userId) {
//       Alert.alert('Error', 'User ID is missing. Please log in.');
//       return;
//     }

//     try {
//       const idToken = await AsyncStorage.getItem('idToken');
//       if (!idToken) {
//         throw new Error('No authentication token found');
//       }
//       const response = await fetch(`${databaseUrl}/addProperty/${userId}.json?auth=${idToken}`);
//       if (!response.ok) {
//         throw new Error('Failed to fetch properties');
//       }
//       const data = await response.json();
//       if (!data) {
//         throw new Error('No data found for this user');
//       }
//       const properties = Object.values(data);
//       setFilteredProperties(properties);
//     } catch (error) {
//       console.error('Error fetching user properties:', error);
//       Alert.alert('Error', error.message || 'Could not fetch properties. Please try again.');
//     }
//   };

//   useEffect(() => {
//     const checkUserAuthentication = async () => {
//       try {
//         const storedUserId = await AsyncStorage.getItem('userId');
//         if (storedUserId) {
//           setUserId(storedUserId);
//           fetchUserProperties(storedUserId);
//         } else {
//           Alert.alert('Error', 'User is not authenticated. Please log in.');
//           navigation.navigate('Login');
//         }
//       } catch (error) {
//         console.error('Error fetching authentication details:', error);
//         Alert.alert('Error', 'Failed to retrieve authentication details.');
//       }
//     };
//     checkUserAuthentication();
//   }, [navigation]);

//   return (
//     <View style={styles.container}>
//       {/* Top Navigation Bar */}
//       <View style={styles.navBar}>
//         <Image source={require('../assets/Logo.png')} style={styles.logo} />
//         <View style={styles.navOptions}>
//           <Text style={styles.navOption}>Stay</Text>
//           <Text style={styles.navOption}>Ease</Text>
//         </View>
//         <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
//           <FontAwesome name="user-circle" size={24} color="black" />
//         </TouchableOpacity>
//       </View>

//       {/* Search Bar */}
//       <View style={styles.searchBar}>
//         <TextInput style={styles.input} placeholder="Location" />
//         <TouchableOpacity style={styles.searchButton}>
//           <FontAwesome name="search" size={20} color="#fff" />
//         </TouchableOpacity>
//       </View>

//       {/* Property Cards */}
//       <ScrollView>
//         {filteredProperties.map((property, index) => (
//           <View key={index} style={styles.propertyCard}>
            
//             {/* Display Images */}
//             {property.images && property.images.length > 0 ? (
//               <ScrollView horizontal>
//                 {property.images.map((img, imgIndex) => (
//                   // Here we use the local URI directly
//                   <Image key={imgIndex} source={{ uri: img.uri }} style={styles.propertyImage} />
//                 ))}
//               </ScrollView>
//             ) : (
//               <Text style={styles.propertyVideo}>No Images Available</Text>
//             )}

//             {/* Display Videos */}
//             {property.videos && property.videos.length > 0 ? (
//               <ScrollView horizontal>
//                 {property.videos.map((videoUrl, videoIndex) => (
//                   <Video
//                     key={videoIndex}
//                     source={{ uri: videoUrl }}
//                     style={styles.videoContainer}
//                     useNativeControls
//                     resizeMode="contain"
//                     isLooping
//                   />
//                 ))}
//               </ScrollView>
//             ) : (
//               <Text style={styles.propertyVideo}>No Video Available</Text>
//             )}

//             {/* Property Details */}
//             <Text style={styles.propertyTitle}>{property.propertyTitle}</Text>
//             <Text style={styles.propertyDescription}>{property.description}</Text>
//             <Text style={styles.propertyPrice}>Price: {property.price}</Text>
//             <Text style={styles.propertyLocation}>Location: {property.propertyLocation}</Text>

//             <Text style={styles.propertySubmittedAt}>
//               Submitted At: {new Date(property.submittedAt).toLocaleString()}
//             </Text>
//           </View>
//         ))}
//       </ScrollView>

//       {/* Add Property Button */}
//       <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('AddPropertyVerification')}>
//         <FontAwesome name="plus-circle" size={24} color="white" />
//         <Text style={styles.addPropertyText}>Add Property</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }

// // Tab Navigator
// const Tab = createBottomTabNavigator();

// const HomeScreenWithTabs = () => {
//   return (
//     <Tab.Navigator
//       screenOptions={({ route }) => ({
//         tabBarIcon: ({ color }) => {
//           let iconName;
//           if (route.name === 'Home') {
//             iconName = 'home-outline';
//           } else if (route.name === 'Notification') {
//             iconName = 'notifications-outline';
//           } else if (route.name === 'Profile') {
//             iconName = 'person-outline';
//           }
//           return <Ionicons name={iconName} size={22} color={color} />;
//         },
//         tabBarActiveTintColor: '#4A90E2',
//         tabBarInactiveTintColor: '#888',
//         tabBarStyle: {
//           backgroundColor: '#ffffff',
//           height: 65,
//           paddingBottom: 10,
//           borderTopWidth: 1,
//           borderTopColor: '#e0e0e0',
//         },
//       })}
//     >
//       <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
//       <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
//       <Tab.Screen name="Profile" component={LandlordProfile} options={{ headerShown: false }} />
//     </Tab.Navigator>
//   );
// };

// // Styles
// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
//   navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
//   logo: { width: 100, height: 30, resizeMode: 'contain' },
//   searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
//   propertyCard: { backgroundColor: '#fff', borderRadius: 8, padding: 10, marginVertical: 10 },
//   propertyImage: { width: 200, height: 120, borderRadius: 5, marginHorizontal: 5 },
//   videoContainer: { width: 200, height: 120, borderRadius: 5, marginHorizontal: 5 },
//   propertyTitle: { fontSize: 16, fontWeight: 'bold', marginTop: 10 },
//   propertyDescription: { fontSize: 12, color: '#666', marginVertical: 5 },
//   propertyPrice: { fontSize: 14, color: '#FF5A5F', fontWeight: 'bold' },
//   propertyLocation: { fontSize: 12, color: '#888' },
//   propertyVideo: { fontSize: 12, color: '#333', marginTop: 5 },
//   propertySubmittedAt: { fontSize: 10, color: '#aaa', marginTop: 5 },
//   addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
//   addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
// });

// export default HomeScreenWithTabs;















import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  TouchableOpacity,
  Alert, ScrollView
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video } from 'expo-av';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Notificationlandlord from './Notificationlandlord';
import LandlordProfile from './LandlordProfile'; // Import the LandlordProfile screen

function HomeScreen({ navigation }) {
  const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com/';
  const [userId, setUserId] = useState(null);
  const [filteredProperties, setFilteredProperties] = useState([]);

  const fetchUserProperties = async (userId) => {
    if (!userId) {
      Alert.alert('Error', 'User ID is missing. Please log in.');
      return;
    }

    try {
      const idToken = await AsyncStorage.getItem('idToken');
      if (!idToken) {
        throw new Error('No authentication token found');
      }
      const response = await fetch(`${databaseUrl}/addProperty/${userId}.json?auth=${idToken}`);
      if (!response.ok) {
        throw new Error('Failed to fetch properties');
      }
      const data = await response.json();
      if (!data) {
        throw new Error('No data found for this user');
      }
      const properties = Object.values(data);
      setFilteredProperties(properties);
    } catch (error) {
      console.error('Error fetching user properties:', error);
      Alert.alert('Error', error.message || 'Could not fetch properties. Please try again.');
    }
  };

  useEffect(() => {
    const checkUserAuthentication = async () => {
      try {
        const storedUserId = await AsyncStorage.getItem('userId');
        if (storedUserId) {
          setUserId(storedUserId);
          fetchUserProperties(storedUserId);
        } else {
          Alert.alert('Error', 'User is not authenticated. Please log in.');
          navigation.navigate('Login');
        }
      } catch (error) {
        console.error('Error fetching authentication details:', error);
        Alert.alert('Error', 'Failed to retrieve authentication details.');
      }
    };
    checkUserAuthentication();
  }, [navigation]);

  return (
    <View style={styles.container}>
      {/* Top Navigation Bar */}
      <View style={styles.navBar}>
        <Image source={require('../assets/Logo.png')} style={styles.logo} />
        <View style={styles.navOptions}>
          <Text style={styles.navOption}>Stay</Text>
          <Text style={styles.navOption}>Ease</Text>
        </View>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <FontAwesome name="user-circle" size={24} color="black" />
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={styles.searchBar}>
        <TextInput style={styles.input} placeholder="Location" />
        <TouchableOpacity style={styles.searchButton}>
          <FontAwesome name="search" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Property Cards */}
      <ScrollView>
        {filteredProperties.map((property, index) => (
          <View key={index} style={styles.propertyCard}>
            
            {/* Display Images */}
            {property.images && property.images.length > 0 ? (
              <ScrollView horizontal>
                {property.images.map((img, imgIndex) => (
                  <Image 
                    key={imgIndex} 
                    source={{ uri: img.uri || 'default-image-url' }} 
                    style={styles.propertyImage} 
                  />
                ))}
              </ScrollView>
            ) : (
              <Text style={styles.propertyVideo}>No Images Available</Text>
            )}

            {/* Display Videos */}
            {property.videos && property.videos.length > 0 ? (
              <ScrollView horizontal>
                {property.videos.map((videoUrl, videoIndex) => (
                  <Video
                    key={videoIndex}
                    source={{ uri: videoUrl }}
                    style={styles.videoContainer}
                    useNativeControls
                    resizeMode="contain"
                    isLooping
                  />
                ))}
              </ScrollView>
            ) : (
              <Text style={styles.propertyVideo}>No Video Available</Text>
            )}

            {/* Property Details */}
            <Text style={styles.propertyTitle}>{property.propertyTitle}</Text>
            <Text style={styles.propertyDescription}>{property.description}</Text>
            <Text style={styles.propertyPrice}>Price: {property.price}</Text>
            <Text style={styles.propertyLocation}>Location: {property.propertyLocation}</Text>

            <Text style={styles.propertySubmittedAt}>
              Submitted At: {new Date(property.submittedAt).toLocaleString()}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* Add Property Button */}
      <TouchableOpacity style={styles.addPropertyButton} onPress={() => navigation.navigate('AddPropertyVerification')}>
        <FontAwesome name="plus-circle" size={24} color="white" />
        <Text style={styles.addPropertyText}>Add Property</Text>
      </TouchableOpacity>
    </View>
  );
}

// Tab Navigator
const Tab = createBottomTabNavigator();

const HomeScreenWithTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color }) => {
          let iconName;
          if (route.name === 'Home') {
            iconName = 'home-outline';
          } else if (route.name === 'Notification') {
            iconName = 'notifications-outline';
          } else if (route.name === 'Profile') {
            iconName = 'person-outline';
          }
          return <Ionicons name={iconName} size={22} color={color} />;
        },
        tabBarActiveTintColor: '#4A90E2',
        tabBarInactiveTintColor: '#888',
        tabBarStyle: {
          backgroundColor: '#ffffff',
          height: 65,
          paddingBottom: 10,
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0',
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Notification" component={Notificationlandlord} options={{ headerShown: true }} />
      <Tab.Screen name="Profile" component={LandlordProfile} options={{ headerShown: false }} />
    </Tab.Navigator>
  );
};

// Styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5', padding: 10 },
  navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  logo: { width: 100, height: 30, resizeMode: 'contain' },
  searchBar: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  propertyCard: { backgroundColor: '#fff', borderRadius: 8, padding: 10, marginVertical: 10 },
  propertyImage: { width: 200, height: 120, borderRadius: 5, marginHorizontal: 5 },
  videoContainer: { width: 200, height: 120, borderRadius: 5, marginHorizontal: 5 },
  propertyTitle: { fontSize: 16, fontWeight: 'bold', marginTop: 10 },
  propertyDescription: { fontSize: 12, color: '#666', marginVertical: 5 },
  propertyPrice: { fontSize: 14, color: '#FF5A5F', fontWeight: 'bold' },
  propertyLocation: { fontSize: 12, color: '#888' },
  propertyVideo: { fontSize: 12, color: '#333', marginTop: 5 },
  propertySubmittedAt: { fontSize: 10, color: '#aaa', marginTop: 5 },
  addPropertyButton: { position: 'absolute', bottom: 20, right: 20, backgroundColor: '#ff5a5f', padding: 15, borderRadius: 50, flexDirection: 'row', alignItems: 'center' },
  addPropertyText: { marginLeft: 10, fontSize: 16, color: 'white' },
});

export default HomeScreenWithTabs;
