import React from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const PropertyRequests = () => {
    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <Ionicons  name="arrow-back-outline"
            size={24}
             color="#000"
             onPress={() => navigation.goBack()} />
                <Text style={styles.headerTitle}>Property Verification Requests</Text>
                <Ionicons name="notifications-outline" size={24} color="#000" />
            </View>

            {/* Search Bar */}
            <View style={styles.searchBarContainer}>
                <Ionicons name="search-outline" size={20} color="gray" style={styles.searchIcon} />
                <TextInput
                    placeholder="Property Verification"
                    style={styles.searchInput}
                    placeholderTextColor="gray"
                />
            </View>

            {/* Tabs */}
            <View style={styles.tabsContainer}>
                <TouchableOpacity style={[styles.tab, styles.activeTab]}>
                    <Text style={styles.tabTextActive}>All Requests</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.tab}>
                    <Text style={styles.tabText}>Pending</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.tab}>
                    <Text style={styles.tabText}>Approved</Text>
                </TouchableOpacity>
            </View>

            {/* Recently Received */}
            <View style={styles.requestSection}>
                <Text style={styles.requestTitle}>Recently Received</Text>
                <Text style={styles.requestDetails}>Verification Pending</Text>
                <Text style={styles.requestDescription}>Seller property is awaiting verification.</Text>
                <Text style={styles.timeText}>2 hours ago</Text>
            </View>

            {/* Verification Approved */}
            <View style={styles.requestSection}>
                <Text style={styles.requestTitle}>Verification Approved</Text>
                <Text style={styles.requestDetails}>Labo Cheema's property has been approved.</Text>
                <Text style={styles.timeText}>1 day ago</Text>
            </View>

            {/* Verification Rejected */}
            <View style={styles.requestSection}>
                <Text style={styles.requestTitle}>Verification Rejected</Text>
                <Text style={styles.requestDetails}>Mike Brown's property request was rejected.</Text>
                <Text style={styles.timeText}>2 days ago</Text>
            </View>

            {/* Property Details */}
            <View style={styles.detailsSection}>
                <Text style={styles.detailsTitle}>Details</Text>
                <Text style={styles.detailsText}><Text style={styles.bold}>Landlord Name:</Text> Maryam Gill</Text>
                <Text style={styles.detailsText}><Text style={styles.bold}>CNIC:</Text> 12345-6789012-3</Text>
                <Text style={styles.detailsText}><Text style={styles.bold}>Registration Number:</Text> 123456</Text>
                <Text style={styles.detailsText}><Text style={styles.bold}>Region:</Text> Garden Town</Text>
                <Text style={styles.detailsText}><Text style={styles.bold}>District:</Text> Gujranwala</Text>
            </View>

            {/* Verify Property Button */}
            <TouchableOpacity style={styles.verifyButton}>
                <Text style={styles.verifyButtonText}>Verify Property</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F7FA',
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 20,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#000',
    },
    searchBarContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#ffffff',
        borderRadius: 8,
        paddingHorizontal: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
        marginBottom: 20,
    },
    searchIcon: {
        marginRight: 10,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#333333',
    },
    tabsContainer: {
        flexDirection: 'row',
        marginBottom: 20,
    },
    tab: {
        flex: 1,
        alignItems: 'center',
        paddingVertical: 10,
        borderRadius: 5,
        backgroundColor: '#E8E8E8',
        marginRight: 10,
    },
    activeTab: {
        backgroundColor: '#4A90E2',
    },
    tabText: {
        color: '#666',
        fontSize: 14,
    },
    tabTextActive: {
        color: '#ffffff',
        fontSize: 14,
    },
    requestSection: {
        marginBottom: 20,
    },
    requestTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#000',
        marginBottom: 5,
    },
    requestDetails: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#4A90E2',
        marginBottom: 5,
    },
    requestDescription: {
        fontSize: 14,
        color: '#666',
        marginBottom: 5,
    },
    timeText: {
        fontSize: 12,
        color: '#999',
    },
    detailsSection: {
        backgroundColor: '#ffffff',
        padding: 15,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
        marginBottom: 20,
    },
    detailsTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#000',
        marginBottom: 10,
    },
    detailsText: {
        fontSize: 14,
        color: '#666',
        marginBottom: 5,
    },
    bold: {
        fontWeight: 'bold',
    },
    verifyButton: {
        backgroundColor: '#5CB85C',
        paddingVertical: 12,
        borderRadius: 8,
        alignItems: 'center',
    },
    verifyButtonText: {
        fontSize: 16,
        color: '#ffffff',
        fontWeight: 'bold',
    },
});

export default PropertyRequests;
