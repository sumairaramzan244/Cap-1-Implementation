// import React from "react";
// import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Alert } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const NotificationDetails = ({ route, navigation }) => {
//   const { notification } = route.params; // Get the notification data from navigation params

//   const handleVerifyProperty = () => {
//     Linking.openURL("https://rod.pulse.gop.pk/"); // Open the verification link in the browser
//   };

//   const handleAccept = async () => {
//     const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";
//     const idToken = await AsyncStorage.getItem("idToken"); // Retrieve the auth token

//     if (!idToken) {
//       Alert.alert("Error", "User is not authenticated.");
//       return;
//     }

//     try {
//       const response = await fetch(
//         `${databaseUrl}/PropertiesVerificationData/${notification.id}.json?auth=${idToken}`,
//         {
//           method: "PATCH",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             status: "Approved", // Update the status to approved
//             isNew: false, // Mark as no longer new
//           }),
//         }
//       );

//       const data = await response.json();

//       if (response.ok) {
//         console.log("Property status updated successfully:", data);
//         Alert.alert("Success", "Property has been approved!");

//         // Navigate landlord to the property upload form
//         navigation.navigate("", { notificationId: notification.id });
//       } else {
//         console.error("Failed to update property status:", data);
//         Alert.alert("Error", data.error?.message || "Failed to update property status.");
//       }
//     } catch (error) {
//       console.error("Error occurred while updating property status:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   const handleReject = async () => {
//     const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";
//     const idToken = await AsyncStorage.getItem("idToken");

//     if (!idToken) {
//       Alert.alert("Error", "User is not authenticated.");
//       return;
//     }

//     try {
//       const response = await fetch(
//         `${databaseUrl}/PropertiesVerificationData/${notification.id}.json?auth=${idToken}`,
//         {
//           method: "PATCH",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             status: "Rejected", // Update the status to rejected
//             isNew: false, // Mark as no longer new
//           }),
//         }
//       );

//       const data = await response.json();

//       if (response.ok) {
//         console.log("Property status updated to rejected:", data);

//         Alert.alert(
//           "Property Rejected",
//           "The property has been rejected. Notify the landlord to provide correct information."
//         );

//         navigation.navigate("HomeScreen"); // Redirect after rejection
//       } else {
//         console.error("Failed to reject property:", data);
//         Alert.alert("Error", data.error?.message || "Failed to reject property.");
//       }
//     } catch (error) {
//       console.error("Error occurred while rejecting property:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       <Text style={styles.title}>Property Details</Text>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Registration Number:</Text>
//         <Text style={styles.value}>{notification.registrationNumber}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Owner Name:</Text>
//         <Text style={styles.value}>{notification.ownerName}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Owner CNIC:</Text>
//         <Text style={styles.value}>{notification.ownerCNIC}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>District:</Text>
//         <Text style={styles.value}>{notification.district}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Region:</Text>
//         <Text style={styles.value}>{notification.region}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Status:</Text>
//         <Text style={styles.value}>{notification.status}</Text>
//       </View>
//       <View style={styles.detailRow}>
//         <Text style={styles.label}>Submitted At:</Text>
//         <Text style={styles.value}>{notification.submittedAt}</Text>
//       </View>

//       {/* Buttons */}
//       <TouchableOpacity style={styles.buttonPrimary} onPress={handleVerifyProperty}>
//         <Text style={styles.buttonText}>Verify Property</Text>
//       </TouchableOpacity>
//       <View style={styles.buttonGroup}>
//         <TouchableOpacity style={styles.buttonAccept} onPress={handleAccept}>
//           <Text style={styles.buttonText}>Accept</Text>
//         </TouchableOpacity>
//         <TouchableOpacity style={styles.buttonReject} onPress={handleReject}>
//           <Text style={styles.buttonText}>Reject</Text>
//         </TouchableOpacity>
//       </View>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flexGrow: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   detailRow: {
//     marginBottom: 15,
//   },
//   label: {
//     fontSize: 16,
//     fontWeight: "bold",
//   },
//   value: {
//     fontSize: 16,
//     color: "#555",
//     marginTop: 5,
//   },
//   buttonPrimary: {
//     backgroundColor: "#007BFF",
//     padding: 15,
//     borderRadius: 5,
//     alignItems: "center",
//     marginTop: 20,
//   },
//   buttonGroup: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     marginTop: 20,
//   },
//   buttonAccept: {
//     backgroundColor: "#28A745",
//     flex: 0.48,
//     padding: 15,
//     borderRadius: 5,
//     alignItems: "center",
//   },
//   buttonReject: {
//     backgroundColor: "#DC3545",
//     flex: 0.48,
//     padding: 15,
//     borderRadius: 5,
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "#FFF",
//     fontWeight: "bold",
//     fontSize: 16,
//   },
// });

// export default NotificationDetails;











import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

const NotificationDetails = ({ route, navigation }) => {
  const { notification } = route.params; // Get notification data

  const handleVerifyProperty = () => {
    Linking.openURL("https://rod.pulse.gop.pk/"); // Open verification link
  };

  const updatePropertyStatus = async (status) => {
    const idToken = await AsyncStorage.getItem("idToken");

    if (!idToken) {
      Alert.alert("Error", "User is not authenticated.");
      return;
    }

    try {
      // Step 1: Update Property Status in Firebase
      const response = await fetch(
        `${databaseUrl}/PropertiesVerificationData/${notification.landlordId}/${notification.id}.json?auth=${idToken}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            status: status, // Update to "Approved" or "Rejected"
            isNew: false, // Mark as no longer new
          }),
        }
      );

      const data = await response.json();

      if (response.ok) {
        console.log(`Property status updated to ${status}:`, data);
        Alert.alert("Success", `Property has been ${status.toLowerCase()}!`);

        // Step 2: Send Notification to Landlord
        await sendLandlordNotification(status);

        // Redirect to HomeScreen after approval/rejection
        navigation.navigate("AdminDashboard");
      } else {
        console.error(`Failed to update property status:`, data);
        Alert.alert("Error", data.error?.message || `Failed to update property status.`);
      }
    } catch (error) {
      console.error("Error updating property status:", error);
      Alert.alert("Error", "Something went wrong. Please try again.");
    }
  };

  const sendLandlordNotification = async (status) => {
    try {
      // Notification Payload
      const notificationData = {
        title: `Property ${status}`,
        message: `Your property with Registration No. ${notification.registrationNumber} has been ${status.toLowerCase()}.`,
        timestamp: new Date().toISOString(),
      };

      // Store notification in landlord's account
      await fetch(`${databaseUrl}/landlordUserAccount/${notification.landlordId}/notifications.json`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(notificationData),
      });

      console.log(`Notification sent to landlord for ${status}`);
    } catch (error) {
      console.error("Error sending notification:", error);
    }
  };

  const confirmAction = (actionType) => {
    Alert.alert(
      `Confirm ${actionType}`,
      `Are you sure you want to ${actionType.toLowerCase()} this property request?`,
      [
        { text: "Cancel", style: "cancel" },
        { text: "OK", onPress: () => updatePropertyStatus(actionType) },
      ]
    );
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Property Details</Text>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Registration Number:</Text>
        <Text style={styles.value}>{notification.registrationNumber}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Owner Name:</Text>
        <Text style={styles.value}>{notification.ownerName}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Owner CNIC:</Text>
        <Text style={styles.value}>{notification.ownerCNIC}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>District:</Text>
        <Text style={styles.value}>{notification.district}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Region:</Text>
        <Text style={styles.value}>{notification.region}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Status:</Text>
        <Text style={styles.value}>{notification.status}</Text>
      </View>
      <View style={styles.detailRow}>
        <Text style={styles.label}>Submitted At:</Text>
        <Text style={styles.value}>{notification.submittedAt}</Text>
      </View>

      {/* Buttons */}
      <TouchableOpacity style={styles.buttonPrimary} onPress={handleVerifyProperty}>
        <Text style={styles.buttonText}>Verify Property</Text>
      </TouchableOpacity>
      <View style={styles.buttonGroup}>
        <TouchableOpacity style={styles.buttonAccept} onPress={() => confirmAction("Approved")}>
          <Text style={styles.buttonText}>Accept</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonReject} onPress={() => confirmAction("Rejected")}>
          <Text style={styles.buttonText}>Reject</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: "#f8f8f8",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  detailRow: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    fontWeight: "bold",
  },
  value: {
    fontSize: 16,
    color: "#555",
    marginTop: 5,
  },
  buttonPrimary: {
    backgroundColor: "#007BFF",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  buttonGroup: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  buttonAccept: {
    backgroundColor: "#28A745",
    flex: 0.48,
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
  buttonReject: {
    backgroundColor: "#DC3545",
    flex: 0.48,
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
  },
  buttonText: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 16,
  },
});

export default NotificationDetails;
