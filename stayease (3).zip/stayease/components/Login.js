
// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   Alert,
//   StyleSheet,
//   ImageBackground,
//   ActivityIndicator,
// } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const Login = ({ navigation }) => {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [errors, setErrors] = useState({});
//   const [showPassword, setShowPassword] = useState(false);
//   const [loading, setLoading] = useState(true); // Added loading state

//   // 🔹 Check if user is already logged in
//  useEffect(() => {
//   const checkLoginStatus = async () => {
//     try {
//       const token = await AsyncStorage.getItem("idToken");
//       const userId = await AsyncStorage.getItem("userId");

//       if (token && userId) {
//         if (userId === "211400125@gift.edu.pk") {
//           navigation.replace("AdminDashboard", { idToken: token });
//         } else {
//           navigation.replace("HomeScreen");
//         }
//       } else {
//         setLoading(false);
//       }
//     } catch (error) {
//       console.error("Error checking login status:", error);
//       setLoading(false);
//     }
//   };

//   checkLoginStatus();
// }, [navigation]); // ✅ Correct Dependency Array

//   const validateForm = () => {
//     let newErrors = {};
//     let hasError = false;

//     if (!username) {
//       newErrors.username = "Email is required.";
//       hasError = true;
//     } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
//       newErrors.username = "Invalid email format.";
//       hasError = true;
//     }

//     if (!password) {
//       newErrors.password = "Password is required.";
//       hasError = true;
//     }

//     setErrors(newErrors);
//     return !hasError;
//   };

//   const handleLogin = async () => {
//     if (!validateForm()) return;

//     try {
//       const response = await fetch(
//         "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU",
//         {
//           method: "POST",
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             email: username,
//             password: password,
//             returnSecureToken: true,
//           }),
//         }
//       );

//       const result = await response.json();
//       console.log("API Response:", result);

//       if (response.ok && result.idToken) {
//         await AsyncStorage.setItem("idToken", result.idToken);
//         await AsyncStorage.setItem("userId", username);
//         Alert.alert("Success", "Logged in successfully!");

//         if (username === "211400125@gift.edu.pk") {
//           navigation.replace("AdminDashboard", { idToken: result.idToken });
//         } else {
//           navigation.replace("HomeScreen");
//         }
//       } else {
//         Alert.alert("Error", result.error?.message || "Invalid credentials.");
//       }
//     } catch (error) {
//       console.error("Login error:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   if (loading) {
//     return (
//       <View style={styles.loadingContainer}>
//         <ActivityIndicator size="large" color="#0275d8" />
//       </View>
//     );
//   }


//   return (
//     <ImageBackground style={styles.background}>
//       <View style={styles.container}>
//         <Text style={styles.title}>Login</Text>
//         <View style={styles.inputContainer}>

//           {/* Email Input */}
//           <Text style={styles.label}>Email <Text style={styles.required}>*</Text></Text>
//           <TextInput
//             placeholder="Enter your email"
//             style={[styles.input, errors.username && styles.errorInput]}
//             value={username}
//             onChangeText={setUsername}
//           />
//           {errors.username && <Text style={styles.errorText}>{errors.username}</Text>}

//           {/* Password Input with Eye Icon */}
//           <Text style={styles.label}>Password <Text style={styles.required}>*</Text></Text>
//           <View style={styles.passwordContainer}>
//             <TextInput
//               placeholder="Enter your password"
//               style={[styles.input, { flex: 1 }]}
//               secureTextEntry={!showPassword}
//               value={password}
//               onChangeText={setPassword}
//             />
//             <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
//               <Text style={styles.eyeText}>{showPassword ? "🙈" : "👁️"}</Text>
//             </TouchableOpacity>
//           </View>
//           {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

//           {/* Login Button */}
//           <TouchableOpacity style={styles.button} onPress={handleLogin}>
//             <Text style={styles.buttonText}>LOGIN</Text>
//           </TouchableOpacity>

//           {/* Forgot Password */}
//           <TouchableOpacity>
//             <Text style={styles.forgotPassword}>Forgot Password?</Text>
//           </TouchableOpacity>

//           {/* Sign Up Link */}
//           <View style={styles.rowContainer}>
//             <Text style={styles.text}>Don't have an account?</Text>
//             <TouchableOpacity
//               style={styles.signupButton}
//               onPress={() => navigation.navigate("CreateAccount")}
//             >
//               <Text style={styles.signupButtonText}>Sign Up</Text>
//             </TouchableOpacity>
//           </View>

//         </View>
//       </View>
//     </ImageBackground>
//   );
// };

// const styles = StyleSheet.create({
//   background: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//     width: "100%",
//     height: "100%",
//   },
//   container: {
//     backgroundColor: "rgba(255, 255, 255, 0.9)",
//     padding: 20,
//     borderRadius: 10,
//     width: "85%",
//     alignItems: "center",
//     borderColor: "#ddd",
//     borderWidth: 1,
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: "bold",
//     marginBottom: 15,
//   },
//   inputContainer: {
//     width: "100%",
//   },
//   label: {
//     fontSize: 16,
//     marginBottom: 5,
//   },
//   required: {
//     color: "red",
//   },
//   input: {
//     height: 45,
//     borderColor: "#ccc",
//     borderWidth: 1,
//     marginBottom: 10,
//     paddingHorizontal: 10,
//     borderRadius: 5,
//     backgroundColor: "#f9f9f9",
//   },
//   errorInput: {
//     borderColor: "red",
//   },
//   errorText: {
//     color: "red",
//     fontSize: 12,
//     marginBottom: 5,
//   },
//   passwordContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     borderColor: "#ccc",
//     borderWidth: 1,
//     borderRadius: 5,
//     marginBottom: 10,
//     paddingHorizontal: 10,
//     backgroundColor: "#f9f9f9",
//   },
//   eyeIcon: {
//     padding: 10,
//   },
//   eyeText: {
//     fontSize: 18,
//     color: "#555",
//   },
//   button: {
//     backgroundColor: "#5cb85c",
//     paddingVertical: 10,
//     borderRadius: 5,
//     marginBottom: 10,
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "white",
//     fontWeight: "bold",
//   },
//   forgotPassword: {
//     color: "blue",
//     textDecorationLine: "underline",
//     marginTop: 10,
//     textAlign: "center",
//   },
//   rowContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginTop: 20,
//   },
//   text: {
//     fontSize: 14,
//     marginRight: 5,
//   },
//   signupButton: {
//     backgroundColor: "#0275d8",
//     paddingVertical: 5,
//     paddingHorizontal: 10,
//     borderRadius: 5,
//   },
//   signupButtonText: {
//     color: "white",
//     fontWeight: "bold",
//     fontSize: 14,
//   },
// });

// export default Login;














import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ImageBackground,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const Login = ({ navigation }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);

  const validateForm = () => {
    let newErrors = {};
    let hasError = false;

    if (!username) {
      newErrors.username = "Email is required.";
      hasError = true;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
      newErrors.username = "Invalid email format.";
      hasError = true;
    }

    if (!password) {
      newErrors.password = "Password is required.";
      hasError = true;
    }

    setErrors(newErrors);
    return !hasError;
  };

  const handleLogin = async () => {
    if (!validateForm()) return;

    try {
      const response = await fetch(
        "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCat6slSntvGnuYDa3DepZpXjGLIclTMWU",
        {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: username,
            password: password,
            returnSecureToken: true,
          }),
        }
      );

      const result = await response.json();
      console.log("API Response:", result);

      if (response.ok && result.idToken) {
        await AsyncStorage.setItem("idToken", result.idToken);
        await AsyncStorage.setItem("userId", result.localId);
        Alert.alert("Success", "Logged in successfully!");

        if (username === "211400125@gift.edu.pk") {
          navigation.navigate("AdminDashboard", { idToken: result.idToken });
        } else {
          navigation.navigate("HomeScreen");
        }
      } else {
        Alert.alert("Error", result.error?.message || "Invalid credentials.");
      }
    } catch (error) {
      console.error("Login error:", error);
      Alert.alert("Error", "Something went wrong. Please try again.");
    }
  };

  return (
    <ImageBackground style={styles.background}>
      <View style={styles.container}>
        <Text style={styles.title}>Login</Text>
        <View style={styles.inputContainer}>

          {/* Email Input */}
          <Text style={styles.label}>Email <Text style={styles.required}>*</Text></Text>
          <TextInput
            placeholder="Enter your email"
            style={[styles.input, errors.username && styles.errorInput]}
            value={username}
            onChangeText={setUsername}
          />
          {errors.username && <Text style={styles.errorText}>{errors.username}</Text>}

          {/* Password Input with Eye Icon */}
          <Text style={styles.label}>Password <Text style={styles.required}>*</Text></Text>
          <View style={styles.passwordContainer}>
            <TextInput
              placeholder="Enter your password"
              style={[styles.input, { flex: 1 }]}
              secureTextEntry={!showPassword}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeIcon}>
              <Text style={styles.eyeText}>{showPassword ? "🙈" : "👁️"}</Text>
            </TouchableOpacity>
          </View>
          {errors.password && <Text style={styles.errorText}>{errors.password}</Text>}

          {/* Login Button */}
          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>LOGIN</Text>
          </TouchableOpacity>

          {/* Forgot Password */}
          <TouchableOpacity>
            <Text style={styles.forgotPassword}>Forgot Password?</Text>
          </TouchableOpacity>

          {/* Sign Up Link */}
          <View style={styles.rowContainer}>
            <Text style={styles.text}>Don't have an account?</Text>
            <TouchableOpacity
              style={styles.signupButton}
              onPress={() => navigation.navigate("CreateAccount")}
            >
              <Text style={styles.signupButtonText}>Sign Up</Text>
            </TouchableOpacity>
          </View>

        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
    height: "100%",
  },
  container: {
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    padding: 20,
    borderRadius: 10,
    width: "85%",
    alignItems: "center",
    borderColor: "#ddd",
    borderWidth: 1,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 15,
  },
  inputContainer: {
    width: "100%",
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
  },
  required: {
    color: "red",
  },
  input: {
    height: 45,
    borderColor: "#ccc",
    borderWidth: 1,
    marginBottom: 10,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: "#f9f9f9",
  },
  errorInput: {
    borderColor: "red",
  },
  errorText: {
    color: "red",
    fontSize: 12,
    marginBottom: 5,
  },
  passwordContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
    backgroundColor: "#f9f9f9",
  },
  eyeIcon: {
    padding: 10,
  },
  eyeText: {
    fontSize: 18,
    color: "#555",
  },
  button: {
    backgroundColor: "#5cb85c",
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "white",
    fontWeight: "bold",
  },
  forgotPassword: {
    color: "blue",
    textDecorationLine: "underline",
    marginTop: 10,
    textAlign: "center",
  },
  rowContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 20,
  },
  text: {
    fontSize: 14,
    marginRight: 5,
  },
  signupButton: {
    backgroundColor: "#0275d8",
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 5,
  },
  signupButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 14,
  },
});

export default Login;









