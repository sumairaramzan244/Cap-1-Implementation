

import React, { useState, useRef, useEffect } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert, Image, StyleSheet, ScrollView } from "react-native";
import * as ImagePicker from "expo-image-picker";
import { WebView } from "react-native-webview";
import AsyncStorage from "@react-native-async-storage/async-storage";

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com"; // Firebase database URL

export default function UploadPropertyForm({ navigation, route }) {
  const [formData, setFormData] = useState({
    propertyTitle: "",
    propertyShared: "",
    propertyLocation: "",
    description: "",
    price: "",
  });








  
  const [images, setImages] = useState([]);
  const [videos, setVideos] = useState([]);
  const [idToken, setIdToken] = useState(null);
  const [userId, setUserId] = useState(null);
  const [address, setAddress] = useState("");
  const webViewRef = useRef(null);
  const propertyId = route.params?.propertyId;

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const token = await AsyncStorage.getItem("idToken");
        const storedUserId = await AsyncStorage.getItem("userId");

        if (!token || !storedUserId) {
          Alert.alert("Error", "User is not authenticated. Redirecting to login.");
          navigation.navigate("Login");
          return;
        }

        setIdToken(token);
        setUserId(storedUserId);
      } catch (error) {
        console.error("Error fetching authentication details:", error);
        Alert.alert("Error", "Failed to retrieve authentication details.");
      }
    };
    fetchUserInfo();
  }, [navigation]);

  const handleInputChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };
const handleImageUpload = async () => {
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (status !== "granted") {
    Alert.alert("Permission Denied", "Grant permissions to upload images.");
    return;
  }

  if (images.length >= 5) {
    Alert.alert("Limit Exceeded", "You can upload a maximum of 5 images.");
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsMultipleSelection: false,
    quality: 1,
  });

  if (!result.canceled && result.assets) {
    const selectedImages = result.assets.map((asset) => ({
      uri: asset.uri,
      name: asset.fileName || asset.uri.split("/").pop(),
      type: asset.type || "image",
    }));
    setImages([...images, ...selectedImages]);
  }
};


const handleVideoUpload = async () => {
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (status !== "granted") {
    Alert.alert("Permission Denied", "Grant permission to upload videos.");
    return;
  }

  if (videos.length >= 2) {
    Alert.alert("Limit Exceeded", "You can upload a maximum of 2 videos.");
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Videos,
    allowsEditing: true,
    quality: 1,
  });

  if (!result.canceled && result.assets) {
    const selectedVideo = result.assets[0];
    setVideos([...videos, {
      uri: selectedVideo.uri,
      name: selectedVideo.fileName || selectedVideo.uri.split("/").pop(),
      type: selectedVideo.type || "video",
    }]);
  }
};

  // Handle location selection
  const handleLocationSelect = () => {
    webViewRef.current.injectJavaScript(`document.getElementById("get-location").click();`);
  };

  // Handle location search
  const handleSearchLocation = () => {
    webViewRef.current.injectJavaScript(`searchLocation("${address}");`);
  };
// Function to remove an image
const handleRemoveImage = (index) => {
  setImages(images.filter((_, i) => i !== index));
};

// Function to remove a video
const handleRemoveVideo = (index) => {
  setVideos(videos.filter((_, i) => i !== index));
};
 const handleSubmit = async () => {
  if (!idToken || !userId) {
    Alert.alert("Error", "User is not authenticated. Please log in again.");
    navigation.navigate("Login");
    return;
  }

  // Validate all required fields
  if (!formData.propertyTitle || !formData.propertyShared || !formData.propertyLocation || !formData.description || !formData.price) {
    Alert.alert("Validation Error", "All fields are required to be filled.");
    return;
  }

  // Validate images: at least 5 images required
  if (images.length < 5) {
    Alert.alert("Validation Error", "You must upload at least 5 images.");
    return;
  }

  // Validate videos: at least 2 videos required
  if (videos.length < 2) {
    Alert.alert("Validation Error", "You must upload at least 2 videos.");
    return;
  }

  try {
    // Remove 'status' field from propertyData
    const propertyData = {
      ...formData,
      images,
      videos,
      isNew: true,  // We can still include 'isNew' if needed
      submittedAt: new Date().toISOString(),
    };

    const response = await fetch(
      `${databaseUrl}/addProperty/${userId}/${propertyId}.json?auth=${idToken}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(propertyData),
      }
    );

    if (response.ok) {
      Alert.alert("Success", "Property Uploaded Successfully");
      setFormData({
        propertyTitle: "",
        propertyShared: "",
        propertyLocation: "",
        description: "",
        price: "",
      });
      setImages([]);
      setVideos([]);
      navigation.navigate("QuestionnaireForm", {
  idToken: idToken,
  userId: userId,
  propertyId: propertyId,  // Make sure you're passing the propertyId here
});


    } else {
      const errorData = await response.json();
      Alert.alert("Error", errorData.error?.message || "Failed to save property data.");
    }
  } catch (error) {
    console.error("Error occurred while saving data:", error);
    Alert.alert("Error", "Something went wrong. Please try again.");
  }
};

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Upload Property Details</Text>

      {/* Property Title */}
      <View style={styles.formGroup}>
        <Text style={styles.label}>Property Title</Text>
        <TextInput
          placeholder="Enter property title (Room, Flat, Apartment)"
          style={styles.input}
          value={formData.propertyTitle}
          onChangeText={(value) => handleInputChange("propertyTitle", value)}
        />
      </View>

      {/* Property Shared */}
      <View style={styles.formGroup}>
        <Text style={styles.label}>Is the property shared?</Text>
        <TextInput
          placeholder="Enter 'Yes' or 'No'"
          style={styles.input}
          value={formData.propertyShared}
          onChangeText={(value) => handleInputChange("propertyShared", value)}
        />
      </View>

      {/* Location */}
      <View style={styles.formGroup}>
        <Text style={styles.label}>Location</Text>
        <TextInput
          placeholder="Enter City, Country, or Area"
          style={styles.input}
          value={address}
          onChangeText={(value) => setAddress(value)}
        />
        <TouchableOpacity style={styles.searchButton} onPress={handleSearchLocation}>
          <Text style={styles.searchButtonText}>Search Location</Text>
        </TouchableOpacity>
      </View>

      {/* Map Location WebView */}
      <View style={styles.mapContainer}>
        <WebView
          ref={webViewRef}
          source={{ html: leafletMapHTML }}
          onMessage={(event) => {
            const location = event.nativeEvent.data;
            handleInputChange("propertyLocation", location);
          }}
          style={styles.map}
        />
      </View>

      {/* Select Location Button */}
      <TouchableOpacity style={styles.selectLocationButton} onPress={handleLocationSelect}>
        <Text style={styles.selectLocationText}>Select Location on Map</Text>
      </TouchableOpacity>

      {/* Property Description */}
      <View style={styles.formGroup}>
        <Text style={styles.label}>Description</Text>
        <TextInput
          placeholder="Enter property description"
          style={styles.input}
          value={formData.description}
          onChangeText={(value) => handleInputChange("description", value)}
          multiline
        />
      </View>

      {/* Price */}
      <View style={styles.formGroup}>
        <Text style={styles.label}>Price</Text>
        <TextInput
          placeholder="Enter price"
          style={styles.input}
          keyboardType="numeric"
          value={formData.price}
          onChangeText={(value) => handleInputChange("price", value)}
        />
      </View>

      {/* Image Upload */}
      <TouchableOpacity style={styles.imageUploadButton} onPress={handleImageUpload}>
        <Text style={styles.imageUploadButtonText}>Upload Images</Text>
      </TouchableOpacity>
      <View style={styles.imagePreviewContainer}>
        {images.map((image, index) => (
          <Image key={index} source={{ uri: image.uri }} style={styles.imagePreview} />
        ))}
      </View>

<View style={styles.imagePreviewContainer}>
  {images.map((image, index) => (
    <View key={index} style={styles.imageWrapper}>
      <Image source={{ uri: image.uri }} style={styles.imagePreview} />
      <TouchableOpacity
        style={styles.removeButton}
        onPress={() => handleRemoveImage(index)}>
        <Text style={styles.removeButtonText}>X</Text>
      </TouchableOpacity>
    </View>
  ))}
</View>

      {/* Video Upload */}
      <TouchableOpacity style={styles.videoUploadButton} onPress={handleVideoUpload}>
        <Text style={styles.videoUploadButtonText}>Upload Video</Text>
      </TouchableOpacity>
      {videos.length > 0 && (
        <View style={styles.videoPreviewContainer}>
          {videos.map((video, index) => (
            <Text key={index} style={styles.videoPreviewText}>Video {index + 1}: {video.name}</Text>
          ))}
        </View>
      )}

<View style={styles.videoPreviewContainer}>
  {videos.map((video, index) => (
    <View key={index} style={styles.videoWrapper}>
      <Text style={styles.videoPreviewText}>Video {index + 1}: {video.name}</Text>
      <TouchableOpacity
        style={styles.removeButton}
        onPress={() => handleRemoveVideo(index)}>
        <Text style={styles.removeButtonText}>X</Text>
      </TouchableOpacity>
    </View>
  ))}
</View>
      {/* Submit Button */}
      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}


const leafletMapHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
  <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
  <style>
    #map { height: 400px; width: 100%; }
  </style>
</head>
<body>
  <div id="map"></div>
  <button id="get-location" style="position: absolute; top: 10px; left: 50%; transform: translateX(-50%); padding: 10px; background: blue; color: white; border-radius: 5px; cursor: pointer;">Select Location</button>
  
  <script>
    var map = L.map('map', {
      center: [30.3753, 69.3451], // Default: Pakistan
      zoom: 5,
      zoomControl: true, // Enable zoom control
      scrollWheelZoom: true, // Enable zoom with scroll wheel
      doubleClickZoom: true, // Enable zoom on double click
      dragging: true // Enable panning
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var marker = L.marker([30.3753, 69.3451], { draggable: true }).addTo(map);

    function onMapClick(e) {
      marker.setLatLng(e.latlng);
    }

    marker.on("dragend", function (e) {
      var latLng = marker.getLatLng();
      window.ReactNativeWebView.postMessage(latLng.lat + "," + latLng.lng);
    });

    map.on('click', onMapClick);

    document.getElementById("get-location").addEventListener("click", function() {
      var latLng = marker.getLatLng();
      window.ReactNativeWebView.postMessage(latLng.lat + "," + latLng.lng);
    });

    function searchLocation(address) {
      fetch(\`https://nominatim.openstreetmap.org/search?format=json&q=\` + address)
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            var lat = data[0].lat;
            var lon = data[0].lon;
            map.setView([lat, lon], 13);
            marker.setLatLng([lat, lon]);
          } else {
            alert("Location not found!");
          }
        })
        .catch(error => console.error(error));
    }
  </script>
</body>
</html>
`;
const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f8f8f8" },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 20, textAlign: "center", color: "#333" },
  formGroup: { marginBottom: 15 },
  label: { fontSize: 16, fontWeight: "600", marginBottom: 5, color: "#555" },
  input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 5, padding: 10, backgroundColor: "#fff", fontSize: 16 },
  searchButton: { backgroundColor: "#FF9800", padding: 10, borderRadius: 5, alignItems: "center", marginTop: 10 },
  searchButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
  mapContainer: { height: 400, borderRadius: 10, overflow: "hidden", marginBottom: 15, borderWidth: 1, borderColor: "#ccc" },
  selectLocationButton: { backgroundColor: "#28A745", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
  selectLocationText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
  imageUploadButton: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
  imageUploadButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
  imagePreviewContainer: { flexDirection: "row", flexWrap: "wrap", marginBottom: 15 },
  imagePreview: { width: 100, height: 100, borderRadius: 5, margin: 5 },
  videoUploadButton: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
  videoUploadButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },

  imageWrapper: { position: "relative", margin: 5 },
  videoWrapper: { position: "relative", marginBottom: 15 },
  
  removeButton: {
    position: "absolute",
    top: 5,
    right: 5,
    backgroundColor: "red",
    borderRadius: 15,
    width: 20,
    height: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  removeButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 14,
  },
  videoPreviewContainer: { marginBottom: 15 },
  videoPreviewText: { fontSize: 16, fontWeight: "600", color: "#555" },
  button: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center" },
  buttonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
});

























// import React, { useState, useRef, useEffect } from "react";
// import { View, Text, TextInput, TouchableOpacity, Alert, Image, StyleSheet, ScrollView } from "react-native";
// import * as ImagePicker from "expo-image-picker";
// import { WebView } from "react-native-webview";
// import AsyncStorage from "@react-native-async-storage/async-storage";
// import { Video } from 'expo-av';

// const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com"; // Firebase database URL

// export default function UploadPropertyForm({ navigation, route }) {
//   const [formData, setFormData] = useState({
//     propertyTitle: "",
//     propertyShared: "",
//     propertyLocation: "",
//     description: "",
//     price: "",
//   });

//   const [images, setImages] = useState([]);
//   const [videos, setVideos] = useState([]);
//   const [idToken, setIdToken] = useState(null);
//   const [userId, setUserId] = useState(null);
//   const [address, setAddress] = useState("");
//   const webViewRef = useRef(null);
//   const propertyId = route.params?.propertyId;

//   useEffect(() => {
//     const fetchUserInfo = async () => {
//       try {
//         const token = await AsyncStorage.getItem("idToken");
//         const storedUserId = await AsyncStorage.getItem("userId");

//         if (!token || !storedUserId) {
//           Alert.alert("Error", "User is not authenticated. Redirecting to login.");
//           navigation.navigate("Login");
//           return;
//         }

//         setIdToken(token);
//         setUserId(storedUserId);
//       } catch (error) {
//         console.error("Error fetching authentication details:", error);
//         Alert.alert("Error", "Failed to retrieve authentication details.");
//       }
//     };
//     fetchUserInfo();
//   }, [navigation]);

//   const handleInputChange = (field, value) => {
//     setFormData({ ...formData, [field]: value });
//   };

//   const handleImageUpload = async () => {
//     const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (status !== "granted") {
//       Alert.alert("Permission Denied", "Grant permissions to upload images.");
//       return;
//     }

//     if (images.length >= 5) {
//       Alert.alert("Limit Exceeded", "You can upload a maximum of 5 images.");
//       return;
//     }

//     const result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaType.Image,
//       allowsMultipleSelection: false,
//       quality: 1,
//     });

//     if (!result.canceled && result.assets) {
//       const selectedImages = result.assets.map((asset) => ({
//         uri: asset.uri,
//         name: asset.fileName || asset.uri.split("/").pop(),
//         type: asset.type || "image",
//       }));
//       setImages([...images, ...selectedImages]);
//     }
//   };

//   const handleVideoUpload = async () => {
//     const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
//     if (status !== "granted") {
//       Alert.alert("Permission Denied", "Grant permission to upload videos.");
//       return;
//     }

//     if (videos.length >= 2) {
//       Alert.alert("Limit Exceeded", "You can upload a maximum of 2 videos.");
//       return;
//     }

//     const result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaType.Video,
//       allowsEditing: true,
//       quality: 1,
//     });

//     if (!result.canceled && result.assets) {
//       const selectedVideo = result.assets[0];
//       setVideos([...videos, {
//         uri: selectedVideo.uri,
//         name: selectedVideo.fileName || selectedVideo.uri.split("/").pop(),
//         type: selectedVideo.type || "video",
//       }]);
//     }
//   };

//   // Handle location selection
//   const handleLocationSelect = () => {
//     webViewRef.current.injectJavaScript(`document.getElementById("get-location").click();`);
//   };

//   // Handle location search
//   const handleSearchLocation = () => {
//     webViewRef.current.injectJavaScript(`searchLocation("${address}");`);
//   };

//   // Function to remove an image
//   const handleRemoveImage = (index) => {
//     setImages(images.filter((_, i) => i !== index));
//   };

//   // Function to remove a video
//   const handleRemoveVideo = (index) => {
//     setVideos(videos.filter((_, i) => i !== index));
//   };

//   const handleSubmit = async () => {
//     if (!idToken || !userId) {
//       Alert.alert("Error", "User is not authenticated. Please log in again.");
//       navigation.navigate("Login");
//       return;
//     }

//     // Validate all required fields
//     if (!formData.propertyTitle || !formData.propertyShared || !formData.propertyLocation || !formData.description || !formData.price) {
//       Alert.alert("Validation Error", "All fields are required to be filled.");
//       return;
//     }

//     // Validate images: at least 5 images required
//     if (images.length < 5) {
//       Alert.alert("Validation Error", "You must upload at least 5 images.");
//       return;
//     }

//     // Validate videos: at least 2 videos required
//     if (videos.length < 2) {
//       Alert.alert("Validation Error", "You must upload at least 2 videos.");
//       return;
//     }

//     try {
//       // Remove 'status' field from propertyData
//       const propertyData = {
//         ...formData,
//         images,
//         videos,
//         isNew: true,  // We can still include 'isNew' if needed
//         submittedAt: new Date().toISOString(),
//       };

//       const response = await fetch(
//         `${databaseUrl}/addProperty/${userId}/${propertyId}.json?auth=${idToken}`,
//         {
//           method: "PUT",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify(propertyData),
//         }
//       );

//       if (response.ok) {
//         Alert.alert("Success", "Property Uploaded Successfully");
//         setFormData({
//           propertyTitle: "",
//           propertyShared: "",
//           propertyLocation: "",
//           description: "",
//           price: "",
//         });
//         setImages([]);
//         setVideos([]);
//         navigation.navigate("QuestionnaireForm", {
//           idToken,
//           userId,
//           propertyId,
//         });
//       } else {
//         const errorData = await response.json();
//         Alert.alert("Error", errorData.error?.message || "Failed to save property data.");
//       }
//     } catch (error) {
//       console.error("Error occurred while saving data:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   return (
//     <ScrollView style={styles.container}>
//       <Text style={styles.title}>Upload Property Details</Text>

//       {/* Property Title */}
//       <View style={styles.formGroup}>
//         <Text style={styles.label}>Property Title</Text>
//         <TextInput
//           placeholder="Enter property title (Room, Flat, Apartment)"
//           style={styles.input}
//           value={formData.propertyTitle}
//           onChangeText={(value) => handleInputChange("propertyTitle", value)}
//         />
//       </View>

//       {/* Property Shared */}
//       <View style={styles.formGroup}>
//         <Text style={styles.label}>Is the property shared?</Text>
//         <TextInput
//           placeholder="Enter 'Yes' or 'No'"
//           style={styles.input}
//           value={formData.propertyShared}
//           onChangeText={(value) => handleInputChange("propertyShared", value)}
//         />
//       </View>

//       {/* Location */}
//       <View style={styles.formGroup}>
//         <Text style={styles.label}>Location</Text>
//         <TextInput
//           placeholder="Enter City, Country, or Area"
//           style={styles.input}
//           value={address}
//           onChangeText={(value) => setAddress(value)}
//         />
//         <TouchableOpacity style={styles.searchButton} onPress={handleSearchLocation}>
//           <Text style={styles.searchButtonText}>Search Location</Text>
//         </TouchableOpacity>
//       </View>

//       {/* Map Location WebView */}
//       <View style={styles.mapContainer}>
//         <WebView
//           ref={webViewRef}
//           source={{ html: leafletMapHTML }}
//           onMessage={(event) => {
//             const location = event.nativeEvent.data;
//             handleInputChange("propertyLocation", location);
//           }}
//           style={styles.map}
//         />
//       </View>

//       {/* Select Location Button */}
//       <TouchableOpacity style={styles.selectLocationButton} onPress={handleLocationSelect}>
//         <Text style={styles.selectLocationText}>Select Location on Map</Text>
//       </TouchableOpacity>

//       {/* Property Description */}
//       <View style={styles.formGroup}>
//         <Text style={styles.label}>Description</Text>
//         <TextInput
//           placeholder="Enter property description"
//           style={styles.input}
//           value={formData.description}
//           onChangeText={(value) => handleInputChange("description", value)}
//           multiline
//         />
//       </View>

//       {/* Price */}
//       <View style={styles.formGroup}>
//         <Text style={styles.label}>Price</Text>
//         <TextInput
//           placeholder="Enter price"
//           style={styles.input}
//           keyboardType="numeric"
//           value={formData.price}
//           onChangeText={(value) => handleInputChange("price", value)}
//         />
//       </View>

//       {/* Image Upload */}
//       <TouchableOpacity style={styles.imageUploadButton} onPress={handleImageUpload}>
//         <Text style={styles.imageUploadButtonText}>Upload Images</Text>
//       </TouchableOpacity>
//       <View style={styles.imagePreviewContainer}>
//         {images.map((image, index) => (
//           <Image key={index} source={{ uri: image.uri }} style={styles.imagePreview} />
//         ))}
//       </View>

//       {/* Remove Images */}
//       <View style={styles.imagePreviewContainer}>
//         {images.map((image, index) => (
//           <View key={index} style={styles.imageWrapper}>
//             <Image source={{ uri: image.uri }} style={styles.imagePreview} />
//             <TouchableOpacity style={styles.removeButton} onPress={() => handleRemoveImage(index)}>
//               <Text style={styles.removeButtonText}>X</Text>
//             </TouchableOpacity>
//           </View>
//         ))}
//       </View>

//       {/* Video Upload */}
//       <TouchableOpacity style={styles.videoUploadButton} onPress={handleVideoUpload}>
//         <Text style={styles.videoUploadButtonText}>Upload Video</Text>
//       </TouchableOpacity>
//       <View style={styles.videoPreviewContainer}>
//         {videos.map((video, index) => (
//           <Text key={index} style={styles.videoPreviewText}>Video {index + 1}: {video.name}</Text>
//         ))}
//       </View>

//       {/* Remove Videos */}
//       <View style={styles.videoPreviewContainer}>
//         {videos.map((video, index) => (
//           <View key={index} style={styles.videoWrapper}>
//             <Text style={styles.videoPreviewText}>Video {index + 1}: {video.name}</Text>
//             <TouchableOpacity style={styles.removeButton} onPress={() => handleRemoveVideo(index)}>
//               <Text style={styles.removeButtonText}>X</Text>
//             </TouchableOpacity>
//           </View>
//         ))}
//       </View>

//       {/* Submit Button */}
//       <TouchableOpacity style={styles.button} onPress={handleSubmit}>
//         <Text style={styles.buttonText}>Submit</Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// }

// const leafletMapHTML = `
// <!DOCTYPE html>
// <html>
// <head>
//   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
//   <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"/>
//   <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
//   <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
//   <style>
//     #map { height: 400px; width: 100%; }
//   </style>
// </head>
// <body>
//   <div id="map"></div>
//   <button id="get-location" style="position: absolute; top: 10px; left: 50%; transform: translateX(-50%); padding: 10px; background: blue; color: white; border-radius: 5px; cursor: pointer;">Select Location</button>
  
//   <script>
//     var map = L.map('map', {
//       center: [30.3753, 69.3451], // Default: Pakistan
//       zoom: 5,
//       zoomControl: true, // Enable zoom control
//       scrollWheelZoom: true, // Enable zoom with scroll wheel
//       doubleClickZoom: true, // Enable zoom on double click
//       dragging: true // Enable panning
//     });

//     L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//       attribution: '© OpenStreetMap contributors'
//     }).addTo(map);

//     var marker = L.marker([30.3753, 69.3451], { draggable: true }).addTo(map);

//     function onMapClick(e) {
//       marker.setLatLng(e.latlng);
//     }

//     marker.on("dragend", function (e) {
//       var latLng = marker.getLatLng();
//       window.ReactNativeWebView.postMessage(latLng.lat + "," + latLng.lng);
//     });

//     map.on('click', onMapClick);

//     document.getElementById("get-location").addEventListener("click", function() {
//       var latLng = marker.getLatLng();
//       window.ReactNativeWebView.postMessage(latLng.lat + "," + latLng.lng);
//     });

//     function searchLocation(address) {
//       fetch(\`https://nominatim.openstreetmap.org/search?format=json&q=\` + address)
//         .then(response => response.json())
//         .then(data => {
//           if (data.length > 0) {
//             var lat = data[0].lat;
//             var lon = data[0].lon;
//             map.setView([lat, lon], 13);
//             marker.setLatLng([lat, lon]);
//           } else {
//             alert("Location not found!");
//           }
//         })
//         .catch(error => console.error(error));
//     }
//   </script>
// </body>
// </html>
// `;
// const styles = StyleSheet.create({
//   container: { flex: 1, padding: 20, backgroundColor: "#f8f8f8" },
//   title: { fontSize: 22, fontWeight: "bold", marginBottom: 20, textAlign: "center", color: "#333" },
//   formGroup: { marginBottom: 15 },
//   label: { fontSize: 16, fontWeight: "600", marginBottom: 5, color: "#555" },
//   input: { borderWidth: 1, borderColor: "#ccc", borderRadius: 5, padding: 10, backgroundColor: "#fff", fontSize: 16 },
//   searchButton: { backgroundColor: "#FF9800", padding: 10, borderRadius: 5, alignItems: "center", marginTop: 10 },
//   searchButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
//   mapContainer: { height: 400, borderRadius: 10, overflow: "hidden", marginBottom: 15, borderWidth: 1, borderColor: "#ccc" },
//   selectLocationButton: { backgroundColor: "#28A745", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
//   selectLocationText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
//   imageUploadButton: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
//   imageUploadButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
//   imagePreviewContainer: { flexDirection: "row", flexWrap: "wrap", marginBottom: 15 },
//   imagePreview: { width: 100, height: 100, borderRadius: 5, margin: 5 },
//   videoUploadButton: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center", marginBottom: 15 },
//   videoUploadButtonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },

//   imageWrapper: { position: "relative", margin: 5 },
//   videoWrapper: { position: "relative", marginBottom: 15 },

//   removeButton: {
//     position: "absolute",
//     top: 5,
//     right: 5,
//     backgroundColor: "red",
//     borderRadius: 15,
//     width: 20,
//     height: 20,
//     justifyContent: "center",
//     alignItems: "center",
//   },
//   removeButtonText: {
//     color: "white",
//     fontWeight: "bold",
//     fontSize: 14,
//   },
//   videoPreviewContainer: { marginBottom: 15 },
//   videoPreviewText: { fontSize: 16, fontWeight: "600", color: "#555" },
//   button: { backgroundColor: "#007BFF", padding: 15, borderRadius: 5, alignItems: "center" },
//   buttonText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
// });
