// import React, { useEffect, useState } from "react";
// import {
//   View,
//   Text,
//   FlatList,
//   StyleSheet,
//   TouchableOpacity,
//   Alert,
// } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const NotificationLandlord = ({ navigation }) => {
//   const [notifications, setNotifications] = useState([]);

//   useEffect(() => {
//     const fetchNotifications = async () => {
//       const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

//       try {
//         const idToken = await AsyncStorage.getItem("idToken"); // Retrieve idToken
//         if (!idToken) {
//           Alert.alert("Error", "User is not authenticated.");
//           return;
//         }

//         const response = await fetch(
//           `${databaseUrl}/PropertiesVerificationData.json?auth=${idToken}`
//         );
//         const data = await response.json();

//         if (data) {
//           console.log("Fetched notifications:", data); // Debug log
//           const formattedNotifications = Object.entries(data).map(
//             ([id, property]) => ({
//               id,
//               ...property,
//             })
//           );
//           setNotifications(formattedNotifications);
//         } else {
//           console.log("No notifications found.");
//         }
//       } catch (error) {
//         console.error("Error fetching notifications:", error);
//         Alert.alert("Error", "Failed to fetch notifications.");
//       }
//     };

//     fetchNotifications();
//   }, []);

//   const handleNotificationPress = (notification) => {
//     if (notification.status === "Approved") {
//       Alert.alert(
//         "Property Approved",
//         "Your property has been approved. Do you want to add details now?",
//         [
//           {
//             text: "Cancel",
//             style: "cancel",
//           },
//           {
//             text: "Add Details",
//             onPress: () => {
//               navigation.navigate("UploadPropertyForm", {
//                 propertyId: notification.id,
//               });
//             },
//           },
//         ]
//       );
//     } else if (notification.status === "Rejected") {
//       Alert.alert(
//         "Property Rejected",
//         "Your property verification has been rejected. Please update your property description and resubmit for verification.",
//         [
//           {
//             text: "OK",
//             onPress: () => {
//               navigation.navigate("AddPropertyVerification", {
//                 propertyId: notification.id,
//               });
//             },
//           },
//         ]
//       );
//     } else {
//       Alert.alert("Under Review", "Your property is still under review.");
//     }
//   };

//   const handleDetailsNavigation = (notification) => {
//     navigation.navigate("NotificationDetailLandlord", {
//       notification, // Pass the notification data to the detail screen
//     });
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Notifications</Text>
//       {notifications.length === 0 ? (
//         <Text style={styles.noNotificationsText}>
//           You have no notifications at the moment.
//         </Text>
//       ) : (
//         <FlatList
//           data={notifications}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity
//               style={styles.notificationCard}
//               onPress={() => handleNotificationPress(item)}
//             >
//               <Text style={styles.notificationText}>
//                 {item.status === "Approved"
//                   ? "Your property has been approved."
//                   : item.status === "Rejected"
//                   ? "Your property submission was rejected."
//                   : "Your property is under review."}
//               </Text>
//               <TouchableOpacity
//                 onPress={() => handleDetailsNavigation(item)}
//               >
//                 <Text style={styles.detailText}>Tap for details</Text>
//               </TouchableOpacity>
//             </TouchableOpacity>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// export default NotificationLandlord;

// // Styles
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   noNotificationsText: {
//     fontSize: 16,
//     textAlign: "center",
//     marginTop: 20,
//     color: "#888",
//   },
//   notificationCard: {
//     backgroundColor: "#fff",
//     padding: 15,
//     borderRadius: 5,
//     marginBottom: 10,
//     elevation: 2,
//   },
//   notificationText: {
//     fontSize: 16,
//     color: "#333",
//     marginBottom: 5,
//   },
//   detailText: {
//     fontSize: 14,
//     color: "#007BFF",
//     textAlign: "right",
//   },
// });




// import React, { useEffect, useState } from "react";
// import {
//   View,
//   Text,
//   FlatList,
//   StyleSheet,
//   TouchableOpacity,
//   Alert,
// } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

// const NotificationLandlord = ({ navigation }) => {
//   const [notifications, setNotifications] = useState([]);

//   useEffect(() => {
//     const fetchNotifications = async () => {
//       try {
//         const idToken = await AsyncStorage.getItem("idToken"); // Retrieve auth token
//         const userId = await AsyncStorage.getItem("userId"); // Get the logged-in landlord's ID

//         if (!idToken || !userId) {
//           Alert.alert("Error", "User is not authenticated.");
//           return;
//         }

//         // Fetch only the logged-in user's notifications
//         const requestUrl = `${databaseUrl}/PropertiesVerificationData/${userId}.json?auth=${idToken}`;
//         const response = await fetch(requestUrl);
//         const data = await response.json();

//         if (data && typeof data === "object" && !data.error) {
//           console.log("Fetched notifications:", data);
//           const formattedNotifications = Object.entries(data).map(
//             ([id, property]) => ({
//               id,
//               ...property,
//             })
//           );
//           setNotifications(formattedNotifications);
//         } else {
//           console.log("No notifications found or permission denied.", data);
//           Alert.alert("Error", "No notifications available.");
//         }
//       } catch (error) {
//         console.error("Error fetching notifications:", error);
//         Alert.alert("Error", "Failed to fetch notifications.");
//       }
//     };

//     fetchNotifications();
//   }, []);

//  const handleNotificationPress = (notification) => {
//   if (notification.status === "Approved") {
//     Alert.alert(
//       "Property Approved",
//       "Your property has been approved. Do you want to add details now?",
//       [
//         { text: "Cancel", style: "cancel" },
//         {
//           text: "Add Details",
//           onPress: () => 
//             navigation.navigate("UploadPropertyForm", { propertyId: notification.id, userId: notification.userId })
//         },
//       ]
//     );
//   } else if (notification.status === "Rejected") {
//     Alert.alert(
//       "Property Rejected",
//       "Your property verification has been rejected. Please update your property description and resubmit for verification.",
//       [
//         {
//           text: "OK",
//           onPress: () => navigation.navigate("AddPropertyVerification", { propertyId: notification.id }),
//         },
//       ]
//     );
//   } else {
//     Alert.alert("Under Review", "Your property is still under review.");
//   }
// };

// const handleDetailsNavigation = (notification) => {
//   console.log("Navigating with notificationId:", notification.id); // Debug Log
//   navigation.navigate("NotificationDetailLandlord", { notificationId: notification.id });
// };


//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Notifications</Text>
//       {notifications.length === 0 ? (
//         <Text style={styles.noNotificationsText}>You have no notifications at the moment.</Text>
//       ) : (
//         <FlatList
//           data={notifications}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <TouchableOpacity style={styles.notificationCard} onPress={() => handleNotificationPress(item)}>
//               <Text style={styles.notificationText}>
//                 {item.status === "Approved"
//                   ? "Your property has been approved."
//                   : item.status === "Rejected"
//                   ? "Your property submission was rejected."
//                   : "Your property is under review."}
//               </Text>
//               <TouchableOpacity onPress={() => handleDetailsNavigation(item)}>
//                 <Text style={styles.detailText}>Tap for details</Text>
//               </TouchableOpacity>
//             </TouchableOpacity>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// export default NotificationLandlord;

// // Styles
// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   noNotificationsText: {
//     fontSize: 16,
//     textAlign: "center",
//     marginTop: 20,
//     color: "#888",
//   },
//   notificationCard: {
//     backgroundColor: "#fff",
//     padding: 15,
//     borderRadius: 5,
//     marginBottom: 10,
//     elevation: 2,
//   },
//   notificationText: {
//     fontSize: 16,
//     color: "#333",
//     marginBottom: 5,
//   },
//   detailText: {
//     fontSize: 14,
//     color: "#007BFF",
//     textAlign: "right",
//   },
// });



// NotificationLandlord Component





import React, { useEffect, useState } from "react";
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

const NotificationLandlord = ({ navigation }) => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const idToken = await AsyncStorage.getItem("idToken"); // Retrieve auth token
        const userId = await AsyncStorage.getItem("userId"); // Get the logged-in landlord's ID

        if (!idToken || !userId) {
          Alert.alert("Error", "User is not authenticated.");
          return;
        }

        // Fetch only the logged-in user's notifications
        const requestUrl = `${databaseUrl}/PropertiesVerificationData/${userId}.json?auth=${idToken}`;
        const response = await fetch(requestUrl);
        const data = await response.json();

        if (data && typeof data === "object" && !data.error) {
          console.log("Fetched notifications:", data);
          const formattedNotifications = Object.entries(data).map(
            ([id, property]) => ({
              id,
              ...property,
            })
          );
          setNotifications(formattedNotifications);
        } else {
          console.log("No notifications found or permission denied.", data);
          Alert.alert("Error", "No notifications available.");
        }
      } catch (error) {
        console.error("Error fetching notifications:", error);
        Alert.alert("Error", "Failed to fetch notifications.");
      }
    };

    fetchNotifications();
  }, []);

  const handleNotificationPress = (notification) => {
    if (notification.status === "Approved") {
      Alert.alert(
        "Property Approved",
        "Your property has been approved. Do you want to add details now?",
        [
          { text: "Cancel", style: "cancel" },
          {
            text: "Add Details",
            onPress: () => 
              navigation.navigate("UploadPropertyForm", { propertyId: notification.id, userId: notification.userId })
          },
        ]
      );
    } else if (notification.status === "Rejected") {
      Alert.alert(
        "Property Rejected",
        "Your property verification has been rejected. Please update your property description and resubmit for verification.",
        [
          {
            text: "OK",
            onPress: () => navigation.navigate("AddPropertyVerification", { propertyId: notification.id }),
          },
        ]
      );
    } else {
      Alert.alert("Under Review", "Your property is still under review.");
    }
  };

  const handleDetailsNavigation = (notification) => {
    console.log("Navigating with notificationId:", notification.id); // Debug Log
    navigation.navigate("NotificationDetailLandlord", { notificationId: notification.id });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Notifications</Text>
      {notifications.length === 0 ? (
        <Text style={styles.noNotificationsText}>You have no notifications at the moment.</Text>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity style={styles.notificationCard} onPress={() => handleNotificationPress(item)}>
              <Text style={styles.notificationText}>
                {item.status === "Approved"
                  ? "Your property has been approved."
                  : item.status === "Rejected"
                  ? "Your property submission was rejected."
                  : "Your property is under review."}
              </Text>
              <TouchableOpacity onPress={() => handleDetailsNavigation(item)}>
                <Text style={styles.detailText}>Tap for details</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

export default NotificationLandlord;

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f8f8f8",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  noNotificationsText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 20,
    color: "#888",
  },
  notificationCard: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
    elevation: 2,
  },
  notificationText: {
    fontSize: 16,
    color: "#333",
    marginBottom: 5,
  },
  detailText: {
    fontSize: 14,
    color: "#007BFF",
    textAlign: "right",
  },
});


