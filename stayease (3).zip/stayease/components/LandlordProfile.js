

// import React, { useEffect, useState } from 'react';
// import { View, Text, StyleSheet, TouchableOpacity, Alert, TextInput, Modal } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';

// const LandlordProfile = ({ navigation }) => {
//   const [userProfile, setUserProfile] = useState(null);
//   const [isEditing, setIsEditing] = useState(false);
//   const [editedProfile, setEditedProfile] = useState({});
//   const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com';

//   useEffect(() => {
//     const fetchUserProfile = async () => {
//       try {
//         const userId = await AsyncStorage.getItem('userId');
//         const idToken = await AsyncStorage.getItem('idToken');

//         console.log('User ID:', userId);
//         console.log('ID Token:', idToken);

//         if (!userId || !idToken) {
//           Alert.alert('Error', 'User not authenticated. Please log in.');
//           navigation.navigate('Login');
//           return;
//         }

//         const response = await fetch(
//           `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`
//         );

//         if (!response.ok) {
//           const errorData = await response.json();
//           console.error('Error Data:', errorData);
//           throw new Error('Failed to fetch user profile');
//         }

//         const userData = await response.json();
//         console.log('Fetched User Data:', userData);
//         setUserProfile(userData);
//         setEditedProfile(userData);  // Initialize edited profile with current data
//       } catch (error) {
//         console.error('Error fetching user profile:', error);
//         Alert.alert('Error', error.message || 'Could not fetch user profile.');
//       }
//     };

//     fetchUserProfile();
//   }, []);

//   const handleUpdateProfile = async () => {
//     try {
//       const userId = await AsyncStorage.getItem('userId');
//       const idToken = await AsyncStorage.getItem('idToken');

//       const response = await fetch(
//         `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`,
//         {
//           method: 'PUT',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify(editedProfile),
//         }
//       );

//       if (!response.ok) {
//         throw new Error('Failed to update profile.');
//       }

//       const updatedData = await response.json();
//       setUserProfile(updatedData);
//       setIsEditing(false);
//       Alert.alert('Success', 'Profile updated successfully!');
//     } catch (error) {
//       console.error('Error updating profile:', error);
//       Alert.alert('Error', error.message || 'Could not update profile.');
//     }
//   };
// const handleDeleteProfile = async () => {
//   Alert.alert(
//     'Confirm Delete',
//     'Are you sure you want to delete your profile permanently?',
//     [
//       { text: 'Cancel', style: 'cancel' }, // If the user cancels, do nothing
//       {
//         text: 'Delete',
//         style: 'destructive',
//         onPress: async () => {
//           try {
//             const userId = await AsyncStorage.getItem('userId');
//             const idToken = await AsyncStorage.getItem('idToken');

//             console.log('Attempting to delete profile for User ID:', userId);

//             // Sending DELETE request to Firebase
//             const response = await fetch(
//               `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`,
//               { method: 'DELETE' }
//             );

//             if (!response.ok) {
//               const errorData = await response.json();
//               console.error('Error Data:', errorData);
//               throw new Error('Failed to delete profile.');
//             }

//             console.log('Profile deleted successfully from Firebase.');

//             // Clear user profile from state and navigate back to login
//             setUserProfile(null);
//             Alert.alert('Deleted', 'Your profile has been permanently deleted.');
//             navigation.navigate('Login');
//           } catch (error) {
//             console.error('Error deleting profile:', error);
//             Alert.alert('Error', error.message || 'Could not delete profile from the database.');
//           }
//         },
//       },
//     ]
//   );
// };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Landlord Profile</Text>

//    {userProfile ? (
//   <>
//     <Text style={styles.text}>Name: {userProfile.name}</Text>
//     <Text style={styles.text}>CNIC: {userProfile.cnic}</Text>
//     <Text style={styles.text}>Contact Number: {userProfile.contactNumber}</Text>
//     <Text style={styles.text}>Address: {userProfile.address}</Text>
//     <Text style={styles.text}>Email: {userProfile.email}</Text> {/* Added Email */}
//     <Text style={styles.text}>Password: {userProfile.password}</Text> {/* Added Password */}

//     <TouchableOpacity style={styles.updateButton} onPress={() => setIsEditing(true)}>
//       <Text style={styles.buttonText}>Update Profile</Text>
//     </TouchableOpacity>

//     <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteProfile}>
//       <Text style={styles.buttonText}>Delete Profile</Text>
//     </TouchableOpacity>
//   </>
// ) : (
//   <Text style={styles.text}>Loading Profile...</Text>
// )}



//       {/* Modal for Editing Profile */}
//       <Modal visible={isEditing} animationType="slide">
//         <View style={styles.container}>
//           <Text style={styles.title}>Edit Profile</Text>

//           <TextInput
//             style={styles.input}
//             placeholder="Name"
//             value={editedProfile.name}
//             onChangeText={(text) => setEditedProfile({ ...editedProfile, name: text })}
//           />
//           <TextInput
//             style={styles.input}
//             placeholder="CNIC"
//             value={editedProfile.cnic}
//             onChangeText={(text) => setEditedProfile({ ...editedProfile, cnic: text })}
//           />
//           <TextInput
//             style={styles.input}
//             placeholder="Contact Number"
//             value={editedProfile.contactNumber}
//             onChangeText={(text) => setEditedProfile({ ...editedProfile, contactNumber: text })}
//           />
//           <TextInput
//             style={styles.input}
//             placeholder="Address"
//             value={editedProfile.address}
//             onChangeText={(text) => setEditedProfile({ ...editedProfile, address: text })}
//           />

//           <TouchableOpacity style={styles.updateButton} onPress={handleUpdateProfile}>
//             <Text style={styles.buttonText}>Save Changes</Text>
//           </TouchableOpacity>

//           <TouchableOpacity style={styles.backButton} onPress={() => setIsEditing(false)}>
//             <Text style={styles.buttonText}>Cancel</Text>
//           </TouchableOpacity>
//         </View>
//       </Modal>
//     </View>
//   );
// };

// export default LandlordProfile;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#f5f5f5',
//     justifyContent: 'center',
//     alignItems: 'center',
//     padding: 20,
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     marginBottom: 20,
//   },
//   text: {
//     fontSize: 18,
//     marginBottom: 10,
//     color: '#333',
//   },
//   input: {
//     width: '100%',
//     padding: 10,
//     borderColor: '#ccc',
//     borderWidth: 1,
//     borderRadius: 5,
//     marginBottom: 15,
//     fontSize: 18,
//   },
//   updateButton: {
//     marginTop: 20,
//     backgroundColor: '#007bff',
//     padding: 10,
//     borderRadius: 5,
//     width: '80%',
//   },
//   deleteButton: {
//     marginTop: 10,
//     backgroundColor: '#dc3545',
//     padding: 10,
//     borderRadius: 5,
//     width: '80%',
//   },
//   backButton: {
//     marginTop: 20,
//     backgroundColor: '#ff5a5f',
//     padding: 10,
//     borderRadius: 5,
//     width: '80%',
//   },
//   buttonText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     textAlign: 'center',
//   },
// });








import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, TextInput, Modal } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/FontAwesome';  // Import the icon library

const LandlordProfile = ({ navigation }) => {
  const [userProfile, setUserProfile] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState({});
  const [passwordVisible, setPasswordVisible] = useState(false); // State to toggle password visibility
  const databaseUrl = 'https://paper-64357-default-rtdb.firebaseio.com';

useEffect(() => {
  const fetchUserProfile = async () => {
    try {
      const userId = await AsyncStorage.getItem('userId');
      const idToken = await AsyncStorage.getItem('idToken');

      if (!userId || !idToken) {
        Alert.alert('Error', 'User not authenticated. Please log in.');
        navigation.navigate('Login');
        return;
      }

      const response = await fetch(
        `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch user profile');
      }

      const userData = await response.json();
      setUserProfile(userData);
      setEditedProfile(userData);
    } catch (error) {
      console.error('Error fetching user profile:', error);
      Alert.alert('Error', error.message || 'Could not fetch user profile.');
    }
  };

  fetchUserProfile();
}, [navigation]);  // ✅ Correct Dependency Array

  const handleUpdateProfile = async () => {
    try {
      const userId = await AsyncStorage.getItem('userId');
      const idToken = await AsyncStorage.getItem('idToken');

      const response = await fetch(
        `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`,
        {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(editedProfile),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to update profile.');
      }

      const updatedData = await response.json();
      setUserProfile(updatedData);
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', error.message || 'Could not update profile.');
    }
  };

  const handleDeleteProfile = async () => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete your profile permanently?',
      [
        { text: 'Cancel', style: 'cancel' }, // If the user cancels, do nothing
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const userId = await AsyncStorage.getItem('userId');
              const idToken = await AsyncStorage.getItem('idToken');

              const response = await fetch(
                `${databaseUrl}/landlordUserAccount/${userId}.json?auth=${idToken}`,
                { method: 'DELETE' }
              );

              if (!response.ok) {
                const errorData = await response.json();
                throw new Error('Failed to delete profile.');
              }

              setUserProfile(null);
              Alert.alert('Deleted', 'Your profile has been permanently deleted.');
              navigation.navigate('Login');
            } catch (error) {
              console.error('Error deleting profile:', error);
              Alert.alert('Error', error.message || 'Could not delete profile from the database.');
            }
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Landlord Profile</Text>

      {userProfile ? (
        <>
          <Text style={styles.text}>Name: {userProfile.name}</Text>
          <Text style={styles.text}>CNIC: {userProfile.cnic}</Text>
          <Text style={styles.text}>Contact Number: {userProfile.contactNumber}</Text>
          <Text style={styles.text}>Address: {userProfile.address}</Text>
          <Text style={styles.text}>Email: {userProfile.email}</Text>

          <TouchableOpacity style={styles.updateButton} onPress={() => setIsEditing(true)}>
            <Text style={styles.buttonText}>Update Profile</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteProfile}>
            <Text style={styles.buttonText}>Delete Profile</Text>
          </TouchableOpacity>
        </>
      ) : (
        <Text style={styles.text}>Loading Profile...</Text>
      )}

      {/* Modal for Editing Profile */}
      <Modal visible={isEditing} animationType="slide">
        <View style={styles.container}>
          <Text style={styles.title}>Edit Profile</Text>

          {/* Name Field */}
          <Text style={styles.label}>Name</Text>
          <TextInput
            style={styles.input}
            placeholder="Name"
            value={editedProfile.name}
            onChangeText={(text) => setEditedProfile({ ...editedProfile, name: text })}
          />

          {/* CNIC Field */}
          <Text style={styles.label}>CNIC</Text>
          <TextInput
            style={styles.input}
            placeholder="CNIC"
            value={editedProfile.cnic}
            onChangeText={(text) => setEditedProfile({ ...editedProfile, cnic: text })}
          />

          {/* Contact Number Field */}
          <Text style={styles.label}>Contact Number</Text>
          <TextInput
            style={styles.input}
            placeholder="Contact Number"
            value={editedProfile.contactNumber}
            onChangeText={(text) => setEditedProfile({ ...editedProfile, contactNumber: text })}
          />

          {/* Address Field */}
          <Text style={styles.label}>Address</Text>
          <TextInput
            style={styles.input}
            placeholder="Address"
            value={editedProfile.address}
            onChangeText={(text) => setEditedProfile({ ...editedProfile, address: text })}
          />

          {/* Password Field wit Eye Icon */}
          <Text style={styles.label}>Password</Text>
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.input}
              placeholder="Password"
              value={editedProfile.password}
              secureTextEntry={!passwordVisible}
              onChangeText={(text) => setEditedProfile({ ...editedProfile, password: text })}
            />
            <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)}>
              <Icon name={passwordVisible ? 'eye-slash' : 'eye'} size={20} color="#000" />
            </TouchableOpacity>
          </View>

          {/* Save Changes Button */}
          <TouchableOpacity style={styles.updateButton} onPress={handleUpdateProfile}>
            <Text style={styles.buttonText}>Save Changes</Text>
          </TouchableOpacity>

          {/* Cancel Button */}
          <TouchableOpacity style={styles.backButton} onPress={() => setIsEditing(false)}>
            <Text style={styles.buttonText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

export default LandlordProfile;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  text: {
    fontSize: 18,
    marginBottom: 10,
    color: '#333',
  },
  input: {
    width: '100%',
    padding: 10,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    fontSize: 18,
  },
  label: {
    fontSize: 18,
    color: '#333',
    marginBottom: 5,
  },
  passwordContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  updateButton: {
    marginTop: 20,
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    width: '80%',
  },
  deleteButton: {
    marginTop: 10,
    backgroundColor: '#dc3545',
    padding: 10,
    borderRadius: 5,
    width: '80%',
  },
  backButton: {
    marginTop: 20,
    backgroundColor: '#ff5a5f',
    padding: 10,
    borderRadius: 5,
    width: '80%',
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
