import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  StatusBar,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import NotificationsScreen from './NotificationScreen'; // Import NotificationsScreen
import ReportsScreen from './ReportsScreen'; // Import ReportsScreen
import SearchScreen from './SearchScreen'; // Import SearchScreen

// Admin Dashboard Screen
const DashboardScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#4A90E2" />
      {/* Header Section */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Admin Dashboard</Text>
        <Ionicons name="person-circle-outline" size={32} color="#ffffff" />
      </View>

      {/* Search Bar */}
      <View style={styles.searchBarContainer}>
        <Ionicons name="search-outline" size={20} color="#555" style={styles.searchIcon} />
        <TextInput
          placeholder="Search here..."
          style={styles.searchInput}
          placeholderTextColor="#aaa"
        />
      </View>

      {/* Functional Sections */}
      <View style={styles.cardContainer}>
        <Text style={styles.cardTitle}>Commission Details</Text>
        <TouchableOpacity
          style={styles.cardButton}
          onPress={() => navigation.navigate('CommissionDetails')}
        >
          <Ionicons name="cash-outline" size={18} color="white" style={styles.iconLeft} />
          <Text style={styles.cardButtonText}>Manage Commission Payments</Text>
          <Ionicons name="arrow-forward-outline" size={18} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.cardContainer}>
        <Text style={styles.cardTitle}>Property Requests</Text>
        <TouchableOpacity
          style={styles.cardButton}
          onPress={() => navigation.navigate('PropertyRequests')}
        >
          <Ionicons name="home-outline" size={18} color="white" style={styles.iconLeft} />
          <Text style={styles.cardButtonText}>Manage Property Requests</Text>
          <Ionicons name="arrow-forward-outline" size={18} color="white" />
        </TouchableOpacity>
      </View>

      <View style={styles.cardContainer}>
        <Text style={styles.cardTitle}>Reports</Text>
        <TouchableOpacity
          style={styles.cardButton}
          onPress={() => navigation.navigate('Reports')}
        >
          <Ionicons name="document-text-outline" size={18} color="white" style={styles.iconLeft} />
          <Text style={styles.cardButtonText}>Reports Type</Text>
          <Ionicons name="arrow-forward-outline" size={18} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

// Tab Navigator
const Tab = createBottomTabNavigator();

const AdminDashboard = () => {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = 'home-outline';
          } else if (route.name === 'Notifications') {
            iconName = 'notifications-outline';
          } else if (route.name === 'Search') {
            iconName = 'search-outline';
          } else if (route.name === 'Reports') {
            iconName = 'document-text-outline';
          }
          return <Ionicons name={iconName} size={22} color={color} />;
        },
        tabBarActiveTintColor: '#4A90E2',
        tabBarInactiveTintColor: '#888',
        tabBarStyle: {
          backgroundColor: '#ffffff',
          height: 65,
          paddingBottom: 10,
          borderTopWidth: 1,
          borderTopColor: '#e0e0e0',
        },
      })}
    >
      <Tab.Screen name="Home" component={DashboardScreen} options={{ headerShown: false }} />
      <Tab.Screen name="Notifications" component={NotificationsScreen} options={{ headerShown: true }} />
      <Tab.Screen name="Search" component={SearchScreen} options={{ headerShown: true }} />
      <Tab.Screen name="Reports" component={ReportsScreen} options={{ headerShown: false }} />
    </Tab.Navigator>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#4A90E2',
    padding: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  searchBarContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ffffff',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333333',
    marginLeft: 10,
  },
  cardContainer: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4A4A4A',
    marginBottom: 10,
  },
  cardButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#4A90E2',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    justifyContent: 'space-between',
  },
  cardButtonText: {
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    marginLeft: 10,
    flex: 1,
  },
  iconLeft: {
    marginRight: 10,
  },
  
});

export default AdminDashboard;
