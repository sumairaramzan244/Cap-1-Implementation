// import React, { useState, useEffect } from "react";
// import { View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, ScrollView } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// export default function AddPropertyVerification({ navigation, route }) {
//   const [formData, setFormData] = useState({
//     registrationNumber: "",
//     ownerName: "",
//     ownerCNIC: "",
//     district: "",
//     region: "",
//   });

//   const [idToken, setIdToken] = useState(null); // Store the ID token
//   const [userId, setUserId] = useState(null); // Store the user ID

//   useEffect(() => {
//     const fetchUserInfo = async () => {
//       const token = route.params?.idToken || (await AsyncStorage.getItem("idToken"));
//       const storedUserId = await AsyncStorage.getItem("userId");
      
//       setIdToken(token);
//       setUserId(storedUserId);
//     };
//     fetchUserInfo();
//   }, [route.params?.idToken]); // Include dependencies to ensure the function runs when ID token changes

//   const handleInputChange = (field, value) => {
//     setFormData({ ...formData, [field]: value });
//   };

//   const submitPropertyData = async () => {
//     const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

//     if (!idToken || !userId) {
//       Alert.alert("Error", "User is not authenticated.");
//       return;
//     }

//     try {
//       const propertyData = {
//         ...formData,
//         status: "Pending",
//         isNew: true, // Mark this submission as new for notifications
//         submittedAt: new Date().toISOString(), // Add a timestamp for reference
//       };

//       // ✅ Save under the specific user's ID
//       const response = await fetch(
//         `${databaseUrl}/PropertiesVerificationData/${userId}.json?auth=${idToken}`,
//         {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify(propertyData),
//         }
//       );

//       if (response.ok) {
//         console.log("Property data saved successfully.");
//         Alert.alert("Success", "Property Verified and Saved Successfully");

//         // Reset form after submission
//         setFormData({
//           registrationNumber: "",
//           ownerName: "",
//           ownerCNIC: "",
//           district: "",
//           region: "",
//         });

//         navigation.navigate("HomeScreen"); // Navigate after submission
//       } else {
//         const errorData = await response.json();
//         console.error("Failed to save property data:", errorData);
//         Alert.alert("Error", errorData.error?.message || "Failed to save property data.");
//       }
//     } catch (error) {
//       console.error("Error occurred while saving data:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       <Text style={styles.title}>Property Verification Form</Text>
//       <TextInput
//         placeholder="Registration Number"
//         style={styles.input}
//         value={formData.registrationNumber}
//         onChangeText={(value) => handleInputChange("registrationNumber", value)}
//       />
//       <TextInput
//         placeholder="Owner Name"
//         style={styles.input}
//         value={formData.ownerName}
//         onChangeText={(value) => handleInputChange("ownerName", value)}
//       />
//       <TextInput
//         placeholder="Owner CNIC"
//         style={styles.input}
//         keyboardType="numeric"
//         value={formData.ownerCNIC}
//         onChangeText={(value) => handleInputChange("ownerCNIC", value)}
//       />
//       <TextInput
//         placeholder="District"
//         style={styles.input}
//         value={formData.district}
//         onChangeText={(value) => handleInputChange("district", value)}
//       />
//       <TextInput
//         placeholder="Region"
//         style={styles.input}
//         value={formData.region}
//         onChangeText={(value) => handleInputChange("region", value)}
//       />
//       <TouchableOpacity style={styles.button} onPress={submitPropertyData}>
//         <Text style={styles.buttonText}>Submit</Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flexGrow: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   input: {
//     borderWidth: 1,
//     borderColor: "#ccc",
//     borderRadius: 5,
//     padding: 10,
//     marginBottom: 15,
//   },
//   button: {
//     backgroundColor: "darkgrey",
//     padding: 15,
//     borderRadius: 5,
//     alignItems: "center",
//   },
//   buttonText: {
//     color: "white",
//     fontWeight: "bold",
//   },
// });





import React, { useState, useEffect } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  Alert, 
  StyleSheet, 
  ScrollView 
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function AddPropertyVerification({ navigation, route }) {
  const [formData, setFormData] = useState({
    registrationNumber: "",
    ownerName: "",
    ownerCNIC: "",
    district: "",
    region: "",
  });

  const [errors, setErrors] = useState({});
  const [idToken, setIdToken] = useState(null);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      const token = route.params?.idToken || (await AsyncStorage.getItem("idToken"));
      const storedUserId = await AsyncStorage.getItem("userId");

      setIdToken(token);
      setUserId(storedUserId);
    };
    fetchUserInfo();
  }, [route.params?.idToken]);

  const handleInputChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    setErrors({ ...errors, [field]: "" }); // Clear error when user types
  };

  const validateForm = () => {
    let newErrors = {};
    let valid = true;

    if (!formData.registrationNumber.trim()) {
      newErrors.registrationNumber = "Registration Number is required.";
      valid = false;
    } else if (!/^\d+$/.test(formData.registrationNumber)) {
      newErrors.registrationNumber = "Must be a numeric value.";
      valid = false;
    }

    if (!formData.ownerName.trim()) {
      newErrors.ownerName = "Owner Name is required.";
      valid = false;
    }

    if (!formData.ownerCNIC.trim()) {
      newErrors.ownerCNIC = "CNIC is required.";
      valid = false;
    } else if (formData.ownerCNIC.length !== 13) {
      newErrors.ownerCNIC = "CNIC must be exactly 13 digits.";
      valid = false;
    }

    if (!formData.district.trim()) {
      newErrors.district = "District is required.";
      valid = false;
    }

    if (!formData.region.trim()) {
      newErrors.region = "Region is required.";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const submitPropertyData = async () => {
    if (!validateForm()) {
      Alert.alert("Validation Error", "Please correct the errors before submitting.");
      return;
    }

    const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com/";

    if (!idToken || !userId) {
      Alert.alert("Error", "User is not authenticated.");
      return;
    }

    try {
      const propertyData = {
        ...formData,
        status: "Pending",
        isNew: true,
        submittedAt: new Date().toISOString(),
      };

      const response = await fetch(
        `${databaseUrl}/PropertiesVerificationData/${userId}.json?auth=${idToken}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(propertyData),
        }
      );

      if (response.ok) {
        console.log("Property data saved successfully.");
        Alert.alert("Success", "Property Verified and Saved Successfully");

        setFormData({
          registrationNumber: "",
          ownerName: "",
          ownerCNIC: "",
          district: "",
          region: "",
        });

        navigation.navigate("HomeScreen");
      } else {
        const errorData = await response.json();
        console.error("Failed to save property data:", errorData);
        Alert.alert("Error", errorData.error?.message || "Failed to save property data.");
      }
    } catch (error) {
      console.error("Error occurred while saving data:", error);
      Alert.alert("Error", "Something went wrong. Please try again.");
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Property Verification Form</Text>

      <TextInput
        placeholder="Registration Number"
        style={[styles.input, errors.registrationNumber && styles.inputError]}
        value={formData.registrationNumber}
        onChangeText={(value) => handleInputChange("registrationNumber", value)}
        keyboardType="numeric"
      />
      {errors.registrationNumber && <Text style={styles.errorText}>{errors.registrationNumber}</Text>}

      <TextInput
        placeholder="Owner Name"
        style={[styles.input, errors.ownerName && styles.inputError]}
        value={formData.ownerName}
        onChangeText={(value) => handleInputChange("ownerName", value)}
      />
      {errors.ownerName && <Text style={styles.errorText}>{errors.ownerName}</Text>}

      <TextInput
        placeholder="Owner CNIC"
        style={[styles.input, errors.ownerCNIC && styles.inputError]}
        keyboardType="numeric"
        value={formData.ownerCNIC}
        onChangeText={(value) => handleInputChange("ownerCNIC", value)}
      />
      {errors.ownerCNIC && <Text style={styles.errorText}>{errors.ownerCNIC}</Text>}

      <TextInput
        placeholder="District"
        style={[styles.input, errors.district && styles.inputError]}
        value={formData.district}
        onChangeText={(value) => handleInputChange("district", value)}
      />
      {errors.district && <Text style={styles.errorText}>{errors.district}</Text>}

      <TextInput
        placeholder="Region"
        style={[styles.input, errors.region && styles.inputError]}
        value={formData.region}
        onChangeText={(value) => handleInputChange("region", value)}
      />
      {errors.region && <Text style={styles.errorText}>{errors.region}</Text>}

      <TouchableOpacity style={styles.button} onPress={submitPropertyData}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// 🎨 **Updated Styles**
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: "#F4F4F4",
    alignItems: "center",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
    color: "#333",
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 12,
    marginBottom: 10,
    fontSize: 16,
    backgroundColor: "#fff",
  },
  inputError: {
    borderColor: "#DC3545",
  },
  errorText: {
    color: "#DC3545",
    fontSize: 14,
    marginBottom: 10,
    alignSelf: "flex-start",
  },
  button: {
    backgroundColor: "#007BFF",
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 8,
    marginTop: 10,
    alignItems: "center",
  },
  buttonText: {
    color: "#FFF",
    fontSize: 16,
    fontWeight: "bold",
  },
});
