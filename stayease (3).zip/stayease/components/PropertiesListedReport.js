import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const PropertiesListedReport = ({ navigation }) => {
  // Extended Sample Data for Properties
  const properties = [
    {
      id: 1,
      landlord: 'unknown',
      property: 'Bridgeland luxury apartment',
      image: 'https://via.placeholder.com/100x100',
    },
    {
      id: 2,
      landlord: 'unknown ',
      property: 'Wayside luxury apartment',
      image: 'https://via.placeholder.com/100x100',
    },
    {
      id: 3,
      landlord: 'unknown ',
      property: 'Shadowfax luxury apartment',
      image: 'https://via.placeholder.com/100x100',
    },
    {
      id: 4,
      landlord: 'unknown ',
      property: 'Palm Gardens estate',
      image: 'https://via.placeholder.com/100x100',
    },
    {
      id: 5,
      landlord: 'unknown ',
      property: 'Golden Heights duplex',
      image: 'https://via.placeholder.com/100x100',
    },
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Ionicons
          name="arrow-back-outline"
          size={24}
          color="#000"
          onPress={() => navigation.goBack()} // Go back to the previous screen
        />
        <Text style={styles.headerTitle}>Properties Listed Report</Text>
        <Ionicons name="document-text-outline" size={24} color="#333" />
      </View>

      {/* Property Cards */}
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {properties.map((property) => (
          <View key={property.id} style={styles.card}>
            <Image source={{ uri: property.image }} style={styles.propertyImage} />
            <View style={styles.propertyDetails}>
              <Text style={styles.landlordName}>{property.landlord}</Text>
              <Text style={styles.propertyInfo}>Landlord: {property.landlord}</Text>
              <Text style={styles.propertyInfo}>Property: {property.property}</Text>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Generate PDF Button */}
      <TouchableOpacity style={styles.generateButton}>
        <Text style={styles.buttonText}>Generate PDF</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  propertyImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginRight: 10,
  },
  propertyDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  landlordName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  propertyInfo: {
    fontSize: 14,
    color: '#555',
  },
  generateButton: {
    backgroundColor: '#4A90E2',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default PropertiesListedReport;
