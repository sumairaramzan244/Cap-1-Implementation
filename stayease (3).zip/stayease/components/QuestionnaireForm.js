


// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TouchableOpacity,
//   Alert,
//   StyleSheet,
//   ScrollView,
// } from "react-native";
// import CheckBox from "expo-checkbox"; // Import checkbox
// import AsyncStorage from "@react-native-async-storage/async-storage"; // For retrieving user ID and token

// const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com/"; // Your Firebase URL

// const QuestionnaireForm = ({ navigation, route }) => {
//   const [responses, setResponses] = useState({
//     petAllowed: false,
//     guestAllowed: false,
//     smokingAllowed: false,
//     furnished: false,
//     parkingAvailable: false,
//     securityAvailable: false,
//     internetAvailable: false,
//     waterIncluded: false,
//     electricityIncluded: false,
//     nearPublicTransport: false,
//     hasBalcony: false,
//     hasLift: false,
//     hasSecurityCameras: false,
//     hasSharedKitchen: false,
//     hasSharedBathroom: false,
//   });

//   const [idToken, setIdToken] = useState(null);
//   const [userId, setUserId] = useState(null);
//   const [propertyId, setPropertyId] = useState(route.params?.propertyId || null);

//   useEffect(() => {
//     const fetchUserInfo = async () => {
//       try {
//         const token = await AsyncStorage.getItem("idToken");
//         const storedUserId = await AsyncStorage.getItem("userId");

//         if (!token || !storedUserId) {
//           Alert.alert("Error", "User is not authenticated. Redirecting to login.");
//           navigation.navigate("Login");
//           return;
//         }

//         setIdToken(token);
//         setUserId(storedUserId);
//       } catch (error) {
//         console.error("Error fetching authentication details:", error);
//         Alert.alert("Error", "Failed to retrieve authentication details.");
//       }
//     };
//     fetchUserInfo();
//   }, [navigation]);

//   const toggleCheckbox = (key) => {
//     setResponses({ ...responses, [key]: !responses[key] });
//   };

//   const handleSubmit = async () => {
//     if (!idToken || !userId || !propertyId) {
//       Alert.alert(
//         "Error",
//         "User is not authenticated or Property ID is missing. Please log in again."
//       );
//       navigation.navigate("Login");
//       return;
//     }

//     try {
//       // Prepare the data to be sent
//       const questionnaireData = {
//         ...responses,
//         submittedAt: new Date().toISOString(),
//       };

//       const response = await fetch(
//         `${databaseUrl}/rulesOfProperty/${userId}/${propertyId}.json?auth=${idToken}`,
//         {
//           method: "PUT",
//           headers: { "Content-Type": "application/json" },
//           body: JSON.stringify(questionnaireData),
//         }
//       );

//       if (response.ok) {
//         Alert.alert("Success", "Your rental property preferences have been saved!");
//         navigation.goBack(); // Navigate back after submission
//       } else {
//         const errorData = await response.json();
//         Alert.alert(
//           "Error",
//           errorData.error?.message || "Failed to save property preferences."
//         );
//       }
//     } catch (error) {
//       console.error("Error occurred while saving data:", error);
//       Alert.alert("Error", "Something went wrong. Please try again.");
//     }
//   };

//   return (
//     <ScrollView style={styles.container}>
//       <Text style={styles.title}>Room/Flat/Apartment Rental Preferences</Text>

//       {Object.keys(responses).map((key) => (
//         <View style={styles.questionContainer} key={key}>
//           <CheckBox
//             value={responses[key]}
//             onValueChange={() => toggleCheckbox(key)}
//           />
//           <Text style={styles.questionText}>{`Is ${key.replace(/([A-Z])/g, ' $1')}`}</Text>
//         </View>
//       ))}

//       <TouchableOpacity style={styles.button} onPress={handleSubmit}>
//         <Text style={styles.buttonText}>Submit</Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   questionContainer: {
//     flexDirection: "row",
//     alignItems: "center",
//     marginBottom: 15,
//   },
//   questionText: {
//     fontSize: 16,
//     marginLeft: 10,
//   },
//   button: {
//     backgroundColor: "#007BFF",
//     padding: 15,
//     borderRadius: 5,
//     alignItems: "center",
//     marginTop: 20,
//   },
//   buttonText: {
//     color: "#FFF",
//     fontWeight: "bold",
//     fontSize: 16,
//   },
// });

// export default QuestionnaireForm;







import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  StyleSheet,
  ScrollView,
} from "react-native";
import CheckBox from "expo-checkbox"; // Import checkbox
import AsyncStorage from "@react-native-async-storage/async-storage"; // For retrieving user ID and token

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com/"; // Your Firebase URL

const QuestionnaireForm = ({ navigation, route }) => {
  const [responses, setResponses] = useState({
    petAllowed: false,
    guestAllowed: false,
    smokingAllowed: false,
    furnished: false,
    parkingAvailable: false,
    securityAvailable: false,
    internetAvailable: false,
    waterIncluded: false,
    electricityIncluded: false,
    nearPublicTransport: false,
    hasBalcony: false,
    hasLift: false,
    hasSecurityCameras: false,
    hasSharedKitchen: false,
    hasSharedBathroom: false,
  });

  const [idToken, setIdToken] = useState(null);
  const [userId, setUserId] = useState(null);
  const [propertyId, setPropertyId] = useState(route.params?.propertyId || null);

  useEffect(() => {
    const fetchUserInfo = async () => {
      try {
        const token = await AsyncStorage.getItem("idToken");
        const storedUserId = await AsyncStorage.getItem("userId");

        if (!token || !storedUserId) {
          Alert.alert("Error", "User is not authenticated. Redirecting to login.");
          navigation.navigate("Login");
          return;
        }

        setIdToken(token);
        setUserId(storedUserId);
      } catch (error) {
        console.error("Error fetching authentication details:", error);
        Alert.alert("Error", "Failed to retrieve authentication details.");
      }
    };
    fetchUserInfo();
  }, [navigation]);

  const toggleCheckbox = (key) => {
    setResponses({ ...responses, [key]: !responses[key] });
  };
const handleSubmit = async () => {
  if (!idToken || !userId || !propertyId) {
    Alert.alert(
      "Error",
      "User is not authenticated or Property ID is missing. Please log in again."
    );
    navigation.navigate("Login");
    return;
  }

  try {
    // Prepare the data to be sent
    const questionnaireData = {
      ...responses,
      submittedAt: new Date().toISOString(),
    };

    const response = await fetch(
      `${databaseUrl}/rulesOfProperty/${userId}/${propertyId}.json?auth=${idToken}`,
      {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(questionnaireData),
      }
    );

    if (response.ok) {
      // Success Alert
      Alert.alert("Success", "Your rental property preferences have been saved!");

      // Navigate back to Home Screen and pass property details as params
      navigation.navigate("HomeScreen", { propertyData: questionnaireData });
    } else {
      const errorData = await response.json();
      Alert.alert(
        "Error",
        errorData.error?.message || "Failed to save property preferences."
      );
    }
  } catch (error) {
    console.error("Error occurred while saving data:", error);
    Alert.alert("Error", "Something went wrong. Please try again.");
  }
};
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Room/Flat/Apartment Rental Preferences</Text>

      {Object.keys(responses).map((key) => (
        <View style={styles.questionContainer} key={key}>
          <CheckBox
            value={responses[key]}
            onValueChange={() => toggleCheckbox(key)}
          />
          <Text style={styles.questionText}>{`Is ${key.replace(/([A-Z])/g, ' $1')}`}</Text>
        </View>
      ))}

      <TouchableOpacity style={styles.button} onPress={handleSubmit}>
        <Text style={styles.buttonText}>Submit</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f8f8f8",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  questionContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  questionText: {
    fontSize: 16,
    marginLeft: 10,
  },
  button: {
    backgroundColor: "#007BFF",
    padding: 15,
    borderRadius: 5,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 16,
  },
});

export default QuestionnaireForm;
