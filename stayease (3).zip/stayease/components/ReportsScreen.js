import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const ReportsScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      {/* Header */}
      <LinearGradient
        colors={['#4A90E2', '#6C63FF']}
        style={styles.headerGradient}
      >
        <Text style={styles.headerTitle}>Reports</Text>
        <Ionicons name="stats-chart" size={40} color="#ffffff" />
      </LinearGradient>

      {/* Subtitle */}
      <Text style={styles.subtitle}>
        Dive into detailed reports and track your performance efficiently.
      </Text>

      {/* Properties Listed Report Button */}
      <TouchableOpacity
        style={[styles.button, styles.shadow]}
        onPress={() => navigation.navigate('PropertiesListedReport')}
      >
        <LinearGradient
          colors={['#6C63FF', '#4A90E2']}
          style={styles.buttonGradient}
        >
          <Text style={styles.buttonText}>📋 Properties Listed Report</Text>
        </LinearGradient>
      </TouchableOpacity>

      {/* Transaction Reports Button */}
      <TouchableOpacity
        style={[styles.button, styles.shadow]}
        onPress={() => navigation.navigate('TransactionReports')}
      >
        <LinearGradient
          colors={['#4A90E2', '#6C63FF']}
          style={styles.buttonGradient}
        >
          <Text style={styles.buttonText}>💳 Transaction Reports</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    padding: 20,
    alignItems: 'center',
  },
  headerGradient: {
    width: '100%',
    padding: 30,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  button: {
    width: '90%',
    marginVertical: 10,
    borderRadius: 10,
  },
  buttonGradient: {
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  shadow: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 5,
    elevation: 8,
  },
});

export default ReportsScreen;
