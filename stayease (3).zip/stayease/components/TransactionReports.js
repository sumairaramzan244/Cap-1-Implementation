import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const TransactionReports = () => {
  // Sample data for transactions
  const transactions = [
    { date: '12/06/2023', id: 'TX123456', amount: 'Rs.12000', status: 'Completed' },
    { date: '16/01/2023', id: 'TX123457', amount: 'Rs.15000', status: 'Completed' },
    { date: '12/02/2023', id: 'TX123458', amount: 'Rs.19000', status: 'Completed' },
    { date: '21/03/2023', id: 'TX123459', amount: 'Rs.13000', status: 'Completed' },
    { date: '14/04/2023', id: 'TX123460', amount: 'Rs.20000', status: 'Pending' },
    { date: '17/04/2024', id: 'TX123461', amount: 'Rs.25000', status: 'Pending' },
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Ionicons    name="arrow-back-outline"
            size={24}
             color="#000"
             onPress={() => navigation.goBack()}  />
        <Text style={styles.headerTitle}>Transaction Reports</Text>
        <Ionicons name="document-text-outline" size={24} color="#333" />
      </View>

      {/* Search Bar */}
      <View style={styles.searchBar}>
        <Ionicons name="search-outline" size={20} color="#888" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search"
          placeholderTextColor="#aaa"
        />
      </View>

      {/* Table Header */}
      <View style={styles.tableHeader}>
        <Text style={styles.tableHeaderText}>Date</Text>
        <Text style={styles.tableHeaderText}>Transaction ID</Text>
        <Text style={styles.tableHeaderText}>Amount</Text>
        <Text style={styles.tableHeaderText}>Status</Text>
      </View>

      {/* Transaction Data */}
      <ScrollView>
        {transactions.map((transaction, index) => (
          <View key={index} style={styles.tableRow}>
            <Text style={styles.tableCell}>{transaction.date}</Text>
            <Text style={styles.tableCell}>{transaction.id}</Text>
            <Text style={styles.tableCell}>{transaction.amount}</Text>
            <Text
              style={[
                styles.tableCell,
                transaction.status === 'Completed'
                  ? styles.statusCompleted
                  : styles.statusPending,
              ]}
            >
              {transaction.status}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* Generate PDF Button */}
      <TouchableOpacity style={styles.generateButton}>
        <Text style={styles.buttonText}>Generate PDF</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FA',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    marginBottom: 20,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#333',
  },
  tableHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingVertical: 5,
    backgroundColor: '#E8E8E8',
    borderRadius: 8,
    paddingHorizontal: 10,
  },
  tableHeaderText: {
    fontWeight: 'bold',
    fontSize: 14,
    color: '#333',
    flex: 1,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 8,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
    marginBottom: 5,
    borderRadius: 8,
  },
  tableCell: {
    flex: 1,
    fontSize: 14,
    color: '#333',
    textAlign: 'center',
  },
  statusCompleted: {
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  statusPending: {
    color: '#FFC107',
    fontWeight: 'bold',
  },
  generateButton: {
    backgroundColor: '#4A90E2',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default TransactionReports;
