// import React, { useEffect, useState } from "react";
// import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const NotificationScreen = ({ navigation }) => {
//   const [notifications, setNotifications] = useState([]);

//   useEffect(() => {
//     const fetchNotifications = async () => {
//       const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

//       try {
//         const idToken = await AsyncStorage.getItem("idToken"); // Retrieve idToken
//         if (!idToken) {
//           Alert.alert("Error", "User is not authenticated.");
//           return;
//         }

//         const response = await fetch(`${databaseUrl}/PropertiesVerificationData.json?auth=${idToken}`);
//         const data = await response.json();

//         if (data) {
//           console.log("Fetched raw data from Firebase:", data);
//           const newNotifications = Object.entries(data)
//             .filter(([id, property]) => property.isNew === true)
//             .map(([id, property]) => ({ id, ...property }));

//           console.log("Filtered notifications:", newNotifications);
//           setNotifications(newNotifications);
//         } else {
//           console.log("No data available in Firebase.");
//         }
//       } catch (error) {
//         console.error("Error fetching notifications:", error);
//         Alert.alert("Error", "Failed to fetch notifications.");
//       }
//     };

//     fetchNotifications();
//   }, []);

//   const handleViewDetails = (notification) => {
//     navigation.navigate("NotificationDetails", { notification }); // Pass notification details to the details screen
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Notifications</Text>
//       {notifications.length === 0 ? (
//         <Text style={styles.noNotificationsText}>You have no new notifications.</Text>
//       ) : (
//         <FlatList
//           data={notifications}
//           keyExtractor={(item) => item.id}
//           renderItem={({ item }) => (
//             <View style={styles.notificationCard}>
//               <Text style={styles.notificationText}>
//                 New Property Submission: {item.registrationNumber} by {item.ownerName}
//               </Text>
//               <TouchableOpacity
//                 style={styles.viewDetailsButton}
//                 onPress={() => handleViewDetails(item)}
//               >
//                 <Text style={styles.viewDetailsButtonText}>View Details</Text>
//               </TouchableOpacity>
//             </View>
//           )}
//         />
//       )}
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//   },
//   title: {
//     fontSize: 22,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//   },
//   noNotificationsText: {
//     fontSize: 16,
//     textAlign: "center",
//     marginTop: 20,
//     color: "#888",
//   },
//   notificationCard: {
//     backgroundColor: "#fff",
//     padding: 15,
//     borderRadius: 5,
//     marginBottom: 10,
//     elevation: 2,
//   },
//   notificationText: {
//     fontSize: 16,
//     marginBottom: 10,
//     color: "#333",
//   },
//   viewDetailsButton: {
//     backgroundColor: "blue",
//     padding: 10,
//     borderRadius: 5,
//     alignItems: "center",
//   },
//   viewDetailsButtonText: {
//     color: "white",
//     fontWeight: "bold",
//   },
// });

// export default NotificationScreen;

import React, { useEffect, useState } from "react";
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

const NotificationScreen = ({ navigation }) => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        // Step 1: Retrieve Authentication Token
        const idToken = await AsyncStorage.getItem("idToken");

        if (!idToken) {
          Alert.alert("Error", "User is not authenticated.");
          return;
        }

        console.log("Using ID Token:", idToken);

        // Step 2: Fetch all landlord IDs from 'PropertiesVerificationData'
        const landlordResponse = await fetch(`${databaseUrl}/PropertiesVerificationData.json?auth=${idToken}`);
        const landlordData = await landlordResponse.json();

        if (!landlordData) {
          console.log("No landlord data found.");
          return;
        }

        const landlordIds = Object.keys(landlordData); // Extract all landlord IDs
        console.log("Landlord IDs:", landlordIds);

        let allPendingProperties = [];

        // Step 3: Fetch properties for each landlord
        for (const landlordId of landlordIds) {
          const propertyResponse = await fetch(`${databaseUrl}/PropertiesVerificationData/${landlordId}.json?auth=${idToken}`);
          const propertyData = await propertyResponse.json();

          if (propertyData) {
            console.log(`Properties for ${landlordId}:`, propertyData);

            // Step 4: Filter only "Pending" properties
            const pendingProperties = Object.entries(propertyData)
              .filter(([id, property]) => property.status === "Pending")
              .map(([id, property]) => ({ id, ...property, landlordId })); // Include landlordId

            allPendingProperties = [...allPendingProperties, ...pendingProperties];
          }
        }

        console.log("All Pending Properties:", allPendingProperties);
        setNotifications(allPendingProperties);
      } catch (error) {
        console.error("Error fetching notifications:", error);
        Alert.alert("Error", "Failed to fetch notifications.");
      }
    };

    fetchNotifications();
  }, []);

  const handleViewDetails = (notification) => {
    navigation.navigate("NotificationDetails", { notification });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Pending Properties</Text>
      {notifications.length === 0 ? (
        <Text style={styles.noNotificationsText}>No pending properties found.</Text>
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.notificationCard}>
              <Text style={styles.notificationText}>
                Pending Property: {item.registrationNumber} by {item.ownerName} (Landlord ID: {item.landlordId})
              </Text>
              <TouchableOpacity
                style={styles.viewDetailsButton}
                onPress={() => handleViewDetails(item)}
              >
                <Text style={styles.viewDetailsButtonText}>View Details</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: "#f8f8f8",
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  noNotificationsText: {
    fontSize: 16,
    textAlign: "center",
    marginTop: 20,
    color: "#888",
  },
  notificationCard: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 5,
    marginBottom: 10,
    elevation: 2,
  },
  notificationText: {
    fontSize: 16,
    marginBottom: 10,
    color: "#333",
  },
  viewDetailsButton: {
    backgroundColor: "blue",
    padding: 10,
    borderRadius: 5,
    alignItems: "center",
  },
  viewDetailsButtonText: {
    color: "white",
    fontWeight: "bold",
  },
});

export default NotificationScreen;
