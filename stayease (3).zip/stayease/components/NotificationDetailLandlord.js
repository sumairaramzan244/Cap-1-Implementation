// import React, { useEffect, useState } from "react";
// import { 
//   View, 
//   Text, 
//   StyleSheet, 
//   ScrollView, 
//   ActivityIndicator, 
//   Alert 
// } from "react-native";
// import AsyncStorage from "@react-native-async-storage/async-storage";

// const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

// const NotificationDetailLandlord = ({ route }) => {
//   const notificationId = route.params?.notificationId; // Ensure notificationId exists
//   const [landlordId, setLandlordId] = useState(null);
//   const [notification, setNotification] = useState(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchLandlordId = async () => {
//       try {
//         const storedLandlordId = await AsyncStorage.getItem("userId"); 
//         const idToken = await AsyncStorage.getItem("idToken");

//         if (!storedLandlordId || !idToken || !notificationId) {
//           Alert.alert("Error", "Invalid data. Please try again.");
//           setLoading(false);
//           return;
//         }

//         console.log(`✅ Landlord ID retrieved: ${storedLandlordId}`);
//         console.log(`🔹 idToken: ${idToken}`);
//         setLandlordId(storedLandlordId);

//         // Fetch the notification data after getting the landlord ID
//         fetchNotification(storedLandlordId, idToken);
//       } catch (error) {
//         console.error("❌ Error fetching landlord ID:", error);
//         Alert.alert("Error", "Failed to retrieve landlord ID.");
//         setLoading(false);
//       }
//     };

//     const fetchNotification = async (landlordId, idToken) => {
//       try {
//         console.log(`📡 Fetching notification for landlordId: ${landlordId} and notificationId: ${notificationId}`);

//         const response = await fetch(
//           `${databaseUrl}/PropertiesVerificationData/${landlordId}/${notificationId}.json?auth=${idToken}`
//         );
//         const data = await response.json();

//         console.log("📜 Fetched Notification Data:", data);

//         if (data && Object.keys(data).length > 0) {
//           setNotification(data);
//         } else {
//           Alert.alert("Error", "No notification details found.");
//         }
//       } catch (error) {
//         console.error("❌ Error fetching notification:", error);
//         Alert.alert("Error", "Something went wrong while fetching the notification.");
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchLandlordId();
//   }, [notificationId]);

//   if (loading) {
//     return (
//       <View style={styles.loadingContainer}>
//         <ActivityIndicator size="large" color="#0000ff" />
//         <Text>Loading Notification...</Text>
//       </View>
//     );
//   }


//   return (
//     <ScrollView contentContainerStyle={styles.container}>
//       <Text style={styles.title}>Notification Details</Text>

//       <View style={styles.detailContainer}>
//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Registration Number:</Text> {notification?.registrationNumber || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Owner Name:</Text> {notification?.ownerName || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Owner CNIC:</Text> {notification?.ownerCNIC || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>District:</Text> {notification?.district || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Region:</Text> {notification?.region || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Status:</Text> {notification?.status || "Not Available"}
//         </Text>

//         <Text style={styles.detailText}>
//           <Text style={styles.label}>Submitted At:</Text> {notification?.submittedAt || "Not Available"}
//         </Text>
//       </View>
//     </ScrollView>
//   );
// };

// export default NotificationDetailLandlord;

// // Styles
// const styles = StyleSheet.create({
//   container: {
//     flexGrow: 1,
//     padding: 20,
//     backgroundColor: "#f8f8f8",
//     alignItems: "center",
//   },
//   loadingContainer: {
//     flex: 1,
//     justifyContent: "center",
//     alignItems: "center",
//   },
 
//   title: {
//     fontSize: 24,
//     fontWeight: "bold",
//     marginBottom: 20,
//     textAlign: "center",
//     color: "#333",
//   },
//   detailContainer: {
//     width: "100%",
//     backgroundColor: "#fff",
//     padding: 15,
//     borderRadius: 10,
//     shadowColor: "#000",
//     shadowOffset: { width: 1, height: 2 },
//     shadowOpacity: 0.2,
//     shadowRadius: 5,
//     elevation: 3, 
//   },
//   detailText: {
//     fontSize: 16,
//     marginBottom: 10,
//     color: "#555",
//   },
//   label: {
//     fontWeight: "bold",
//     color: "#000",
//   },
// });





import React, { useEffect, useState } from "react";
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  ActivityIndicator, 
  Alert 
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const databaseUrl = "https://paper-64357-default-rtdb.firebaseio.com";

const NotificationDetailLandlord = ({ route }) => {
  const notificationId = route.params?.notificationId;
  const [landlordId, setLandlordId] = useState(null);
  const [notification, setNotification] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLandlordId = async () => {
      try {
        const storedLandlordId = await AsyncStorage.getItem("userId"); 
        const idToken = await AsyncStorage.getItem("idToken");

        if (!storedLandlordId || !idToken || !notificationId) {
          Alert.alert("Error", "Invalid data. Please try again.");
          setLoading(false);
          return;
        }

        console.log(`✅ Landlord ID retrieved: ${storedLandlordId}`);
        setLandlordId(storedLandlordId);

        fetchNotification(storedLandlordId, idToken);
      } catch (error) {
        console.error("❌ Error fetching landlord ID:", error);
        Alert.alert("Error", "Failed to retrieve landlord ID.");
        setLoading(false);
      }
    };

    const fetchNotification = async (landlordId, idToken) => {
      try {
        console.log(`📡 Fetching notification for landlordId: ${landlordId} and notificationId: ${notificationId}`);

        const response = await fetch(
          `${databaseUrl}/PropertiesVerificationData/${landlordId}/${notificationId}.json?auth=${idToken}`
        );
        const data = await response.json();

        console.log("📜 Fetched Notification Data:", data);

        if (data && Object.keys(data).length > 0) {
          setNotification(data);
        } else {
          Alert.alert("Error", "No notification details found.");
        }
      } catch (error) {
        console.error("❌ Error fetching notification:", error);
        Alert.alert("Error", "Something went wrong while fetching the notification.");
      } finally {
        setLoading(false);
      }
    };

    fetchLandlordId();
  }, [notificationId]);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007BFF" />
        <Text style={styles.loadingText}>Fetching details...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Property Details</Text>

      <View style={styles.detailContainer}>
        <View style={styles.infoRow}>
          <Text style={styles.label}>Registration Number:</Text>
          <Text style={styles.value}>{notification?.registrationNumber || "Not Available"}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>Owner Name:</Text>
          <Text style={styles.value}>{notification?.ownerName || "Not Available"}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>Owner CNIC:</Text>
          <Text style={styles.value}>{notification?.ownerCNIC || "Not Available"}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>District:</Text>
          <Text style={styles.value}>{notification?.district || "Not Available"}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>Region:</Text>
          <Text style={styles.value}>{notification?.region || "Not Available"}</Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>Status:</Text>
          <Text style={[styles.value, styles.status(notification?.status)]}>
            {notification?.status || "Not Available"}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <Text style={styles.label}>Submitted At:</Text>
          <Text style={styles.value}>{notification?.submittedAt || "Not Available"}</Text>
        </View>
      </View>
    </ScrollView>
  );
};

export default NotificationDetailLandlord;

// 💠 **Updated Styles**
const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: "#f4f4f4",
    alignItems: "center",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#555",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#222",
    textAlign: "center",
  },
  detailContainer: {
    width: "100%",
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 2, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 5,
    elevation: 4, // For Android shadow effect
  },
  infoRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
    paddingVertical: 10,
  },
  label: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
  },
  value: {
    fontSize: 16,
    color: "#555",
  },
  status: (status) => ({
    color: status === "Approved" ? "#28A745" : status === "Rejected" ? "#DC3545" : "#FFC107",
    fontWeight: "bold",
  }),
});
