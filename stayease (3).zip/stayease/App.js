import React from 'react';
import { NavigationContainer } from '@react-navigation/native'; // Keep NavigationContainer here
import { createStackNavigator } from '@react-navigation/stack';
import FrontScreen from './components/FrontScreen'; // Import your FrontScreen
import HomeScreen from './components/HomeScreen'; // Import your HomeScreen
import Login from './components/Login'
import CreateAccount from './components/CreateAccount'
import AddPropertyVerification from './components/AddPropertyVerification'
import UploadPropertyForm from './components/UploadPropertyForm'
import UserRoleSelection from './components/UserRoleSelection'
import AdminDashboard from './components/AdminDashboard'
import AdminLogin from './components/AdminLogin'
import NotificationScreen from './components/NotificationScreen'
import NotificationDetails from './components/NotificationDetails'
import NotificationLandlord from './components/Notificationlandlord'
import NotificationDetailLandlord from './components/NotificationDetailLandlord';

import LandlordProfile from './components/LandlordProfile'
               import CommissionDetails from './components/CommissionDetails'; // Ensure the path to CommissionDetails is correct
import PropertyRequests from './components/PropertyRequests'; // Ensure the path to PropertyRequests is correct
import ReportsScreen from './components/ReportsScreen'; // Ensure the path to ReportsScreen is correct

import PropertiesListedReport from './components/PropertiesListedReport'; // Ensure the path to PropertiesListedReport is correct
import TransactionReports from './components/TransactionReports'; // Ensure the path to TransactionReports is correct
import QuestionnaireForm from './components/QuestionnaireForm'
                               
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer> {/* Only one NavigationContainer should be here */}
      <Stack.Navigator initialRouteName="FrontScreen">
        <Stack.Screen name="FrontScreen" component={FrontScreen}options={{ headerShown: false }} />
        <Stack.Screen name="HomeScreen" component={HomeScreen} />
           <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="CreateAccount" component={CreateAccount} />
                <Stack.Screen name="AddPropertyVerification" component={AddPropertyVerification} />
                <Stack.Screen name='UploadPropertyForm' component={UploadPropertyForm}/>
                <Stack.Screen name="UserRoleSelection" component={UserRoleSelection} options={{ headerShown: false }} />
               <Stack.Screen name='AdminDashboard' component={AdminDashboard}/> 
               <Stack.Screen name='AdminLogin' component={AdminLogin}/> 

  <Stack.Screen name="NotificationDetails" component={NotificationDetails} options={{ title: "Details" }} />
  <Stack.Screen name="NotificationScreen" component={NotificationScreen} options={{ headerShown: false }} />
  <Stack.Screen name="NotificationLandlord" component={NotificationLandlord} options={{ headerShown: false }} />
    <Stack.Screen name="NotificationDetailLandlord" component={NotificationDetailLandlord}  />
  <Stack.Screen name="QuestionnaireForm" component={QuestionnaireForm}/>
  
  <Stack.Screen name="LandlordProfile" component={LandlordProfile}/>
        {/* Commission Details */}
        <Stack.Screen
          name="CommissionDetails"
          component={CommissionDetails}
          options={{ headerShown: false }}
        />


        {/* Property Requests */}
        <Stack.Screen
          name="PropertyRequests"
          component={PropertyRequests}
          options={{ headerShown: false }}
        />

        {/* Reports Screen */}
        <Stack.Screen
          name="ReportsScreen"
          component={ReportsScreen}
          options={{ headerShown: false }}
        />


        {/* Properties Listed Report */}
        <Stack.Screen
          name="PropertiesListedReport"
          component={PropertiesListedReport}
          options={{ headerShown: false }}
        />

        {/* Transaction Reports */}
        <Stack.Screen
          name="TransactionReports"
          component={TransactionReports}
          options={{ headerShown: false }}
        />
    
      </Stack.Navigator>

    </NavigationContainer>
  );
}
